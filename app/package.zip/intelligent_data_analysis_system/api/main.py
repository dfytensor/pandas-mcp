#!/usr/bin/env python3
"""
智能数据问答分析系统 - FastAPI后端服务
提供REST API接口
"""

from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import asyncio
import time
import uuid
import os
import io
from loguru import logger

from core.agent_coordinator import coordinator
from core.enhanced_fastmcp import engine
from core.config import API_CONFIG, FRONTEND_CONFIG


# Pydantic模型
class QueryRequest(BaseModel):
    query: str
    dataset_id: Optional[str] = None
    session_id: Optional[str] = None


class QueryResponse(BaseModel):
    success: bool
    session_id: str
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    processing_time: Optional[float] = None


class DatasetInfo(BaseModel):
    dataset_id: str
    name: str
    data_type: str
    shape: List[int]
    columns: List[str]
    upload_time: str


class ProcessingStats(BaseModel):
    total_requests: int
    successful_requests: int
    failed_requests: int
    average_processing_time: float
    workflow_distribution: Dict[str, int]


# 创建FastAPI应用
app = FastAPI(
    title=API_CONFIG["title"],
    description=API_CONFIG["description"],
    version=API_CONFIG["version"]
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=API_CONFIG.get("allowed_origins", ["*"]),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """应用启动事件"""
    logger.info("智能数据问答分析系统启动")
    logger.info(f"API服务地址: http://{API_CONFIG['host']}:{API_CONFIG['port']}")
    logger.info(f"前端服务地址: http://{FRONTEND_CONFIG['server_name']}:{FRONTEND_CONFIG['server_port']}")


@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭事件"""
    logger.info("智能数据问答分析系统关闭")


@app.get("/")
async def root():
    """根路径"""
    return {
        "message": "智能数据问答分析系统API",
        "version": API_CONFIG["version"],
        "status": "running",
        "endpoints": {
            "query": "/query",
            "upload": "/upload",
            "datasets": "/datasets",
            "stats": "/stats",
            "health": "/health"
        }
    }


@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "services": {
            "coordinator": "running",
            "mcp_engine": "running",
            "agents": "running"
        }
    }


@app.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    """处理用户查询"""
    try:
        # 生成会话ID
        session_id = request.session_id or f"session_{uuid.uuid4().hex[:8]}"
        
        logger.info(f"处理查询请求: {request.query[:50]}... (会话: {session_id})")
        
        # 调用协调器处理查询
        result = await coordinator.process_query(
            user_query=request.query,
            dataset_id=request.dataset_id,
            session_id=session_id
        )
        
        return QueryResponse(
            success=result.get('success', False),
            session_id=session_id,
            result=result if result.get('success', False) else None,
            error=result.get('error') if not result.get('success', True) else None,
            processing_time=result.get('processing_info', {}).get('total_processing_time')
        )
        
    except Exception as e:
        logger.error(f"处理查询失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"查询处理失败: {str(e)}")


@app.post("/upload")
async def upload_dataset(
    file: UploadFile = File(...),
    dataset_name: Optional[str] = Query(None, description="数据集名称"),
    data_type: Optional[str] = Query("auto", description="数据类型")
):
    """上传数据集"""
    try:
        # 验证文件类型
        allowed_extensions = ['.csv', '.json', '.xlsx', '.xls', '.db']
        file_extension = os.path.splitext(file.filename)[1].lower()
        
        if file_extension not in allowed_extensions:
            raise HTTPException(
                status_code=400, 
                detail=f"不支持的文件类型: {file_extension}。支持的类型: {allowed_extensions}"
            )
        
        # 读取文件内容
        content = await file.read()
        
        # 生成数据集名称
        if not dataset_name:
            dataset_name = f"uploaded_{int(time.time())}_{file.filename}"
        
        logger.info(f"上传数据集: {dataset_name}, 类型: {data_type}, 大小: {len(content)} bytes")
        
        # 加载数据
        if data_type == "csv":
            result = engine.load_data(content.decode('utf-8'), "csv", dataset_name)
        elif data_type == "json":
            result = engine.load_data(content.decode('utf-8'), "json", dataset_name)
        elif data_type == "excel":
            result = engine.load_data(content, "excel", dataset_name)
        elif data_type == "sqlite":
            # 保存SQLite文件
            file_path = f"data/{dataset_name}.db"
            os.makedirs("data", exist_ok=True)
            with open(file_path, "wb") as f:
                f.write(content)
            result = engine.load_data(dataset_name, "sqlite", dataset_name)
        else:
            # 自动检测类型
            result = engine.load_data(content, "auto", dataset_name)
        
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        
        return {
            "success": True,
            "dataset_id": result["dataset_id"],
            "message": result["message"],
            "data_shape": result["data_shape"],
            "columns": result["columns"],
            "data_quality": result.get("data_quality", {})
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"上传数据集失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"上传失败: {str(e)}")


@app.get("/datasets")
async def list_datasets():
    """列出所有数据集"""
    try:
        datasets_info = []
        
        for dataset_id, dataset_info in engine.datasets.items():
            df = dataset_info["data"]
            datasets_info.append({
                "dataset_id": dataset_id,
                "name": dataset_id,
                "data_type": dataset_info.get("data_type", "unknown"),
                "shape": list(df.shape),
                "columns": list(df.columns),
                "upload_time": dataset_info.get("timestamp", 0),
                "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2)
            })
        
        return {
            "success": True,
            "datasets": datasets_info,
            "total_count": len(datasets_info)
        }
        
    except Exception as e:
        logger.error(f"获取数据集列表失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"获取数据集列表失败: {str(e)}")


@app.get("/datasets/{dataset_id}")
async def get_dataset_info(dataset_id: str):
    """获取数据集详细信息"""
    try:
        result = engine.get_dataset_info(dataset_id)
        
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        
        return {
            "success": True,
            "dataset_info": result
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"获取数据集信息失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"获取数据集信息失败: {str(e)}")


@app.delete("/datasets/{dataset_id}")
async def delete_dataset(dataset_id: str):
    """删除数据集"""
    try:
        if dataset_id not in engine.datasets:
            raise HTTPException(status_code=404, detail=f"数据集不存在: {dataset_id}")
        
        # 删除数据集
        del engine.datasets[dataset_id]
        
        # 如果删除的是当前数据集，清除当前数据集ID
        if engine.current_dataset_id == dataset_id:
            engine.current_dataset_id = None
        
        logger.info(f"删除数据集: {dataset_id}")
        
        return {
            "success": True,
            "message": f"数据集 {dataset_id} 已删除"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"删除数据集失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"删除数据集失败: {str(e)}")


@app.get("/stats")
async def get_processing_stats():
    """获取处理统计信息"""
    try:
        stats = coordinator.get_processing_stats()
        
        return {
            "success": True,
            "stats": stats
        }
        
    except Exception as e:
        logger.error(f"获取统计信息失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"获取统计信息失败: {str(e)}")


@app.get("/sessions/{session_id}")
async def get_session_status(session_id: str):
    """获取会话状态"""
    try:
        status = await coordinator.get_session_status(session_id)
        
        return {
            "success": True,
            "session_status": status
        }
        
    except Exception as e:
        logger.error(f"获取会话状态失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"获取会话状态失败: {str(e)}")


@app.post("/cleanup")
async def cleanup_expired_data(background_tasks: BackgroundTasks):
    """清理过期数据"""
    try:
        # 在后台任务中执行清理
        background_tasks.add_task(perform_cleanup)
        
        return {
            "success": True,
            "message": "清理任务已启动"
        }
        
    except Exception as e:
        logger.error(f"启动清理任务失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"启动清理任务失败: {str(e)}")


async def perform_cleanup():
    """执行清理任务"""
    try:
        logger.info("开始执行数据清理任务")
        
        # 清理过期数据集
        cleaned_datasets = engine.cleanup_old_datasets()
        
        # 清理过期会话
        cleaned_sessions = coordinator.cleanup_sessions()
        
        logger.info(f"清理完成: {cleaned_datasets} 个数据集, {cleaned_sessions} 个会话")
        
    except Exception as e:
        logger.error(f"清理任务执行失败: {str(e)}")


@app.get("/available-datasets")
async def get_available_sklearn_datasets():
    """获取可用的sklearn数据集"""
    try:
        from .core.config import AVAILABLE_DATASETS
        
        return {
            "success": True,
            "datasets": AVAILABLE_DATASETS
        }
        
    except Exception as e:
        logger.error(f"获取可用数据集失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"获取可用数据集失败: {str(e)}")


@app.post("/load-sklearn-dataset")
async def load_sklearn_dataset(dataset_name: str, custom_name: Optional[str] = None):
    """加载sklearn数据集"""
    try:
        from .core.config import AVAILABLE_DATASETS
        
        if dataset_name not in AVAILABLE_DATASETS:
            raise HTTPException(
                status_code=400, 
                detail=f"不支持的数据集: {dataset_name}。可用数据集: {list(AVAILABLE_DATASETS.keys())}"
            )
        
        # 加载数据集
        result = engine.load_data(dataset_name, "sk-learn", custom_name)
        
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        
        return {
            "success": True,
            "dataset_id": result["dataset_id"],
            "message": result["message"],
            "data_shape": result["data_shape"],
            "columns": result["columns"],
            "description": AVAILABLE_DATASETS[dataset_name]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"加载sklearn数据集失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"加载sklearn数据集失败: {str(e)}")


@app.get("/docs")
async def get_api_docs():
    """获取API文档"""
    return {
        "title": "智能数据问答分析系统API文档",
        "version": API_CONFIG["version"],
        "description": "提供智能数据分析和问答功能的REST API",
        "endpoints": {
            "POST /query": {
                "description": "处理用户自然语言查询",
                "parameters": {
                    "query": "用户查询字符串",
                    "dataset_id": "可选的数据集ID",
                    "session_id": "可选的会话ID"
                }
            },
            "POST /upload": {
                "description": "上传数据集文件",
                "parameters": {
                    "file": "数据文件",
                    "dataset_name": "可选的数据集名称",
                    "data_type": "数据类型 (auto/csv/json/excel/sqlite)"
                }
            },
            "GET /datasets": "获取所有数据集列表",
            "GET /datasets/{dataset_id}": "获取数据集详细信息",
            "DELETE /datasets/{dataset_id}": "删除数据集",
            "GET /stats": "获取处理统计信息",
            "GET /sessions/{session_id}": "获取会话状态",
            "POST /load-sklearn-dataset": "加载sklearn内置数据集"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api.main:app",
        host=API_CONFIG["host"],
        port=API_CONFIG["port"],
        reload=API_CONFIG["debug"]
    )