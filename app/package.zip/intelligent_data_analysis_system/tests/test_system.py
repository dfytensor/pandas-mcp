#!/usr/bin/env python3
"""
智能数据问答分析系统 - 测试脚本
用于测试系统各项功能
"""

import asyncio
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from loguru import logger

# 导入系统组件
from core.enhanced_fastmcp import engine
from core.agent_coordinator import coordinator


class SystemTester:
    """系统测试器"""
    
    def __init__(self):
        self.test_results = []
        logger.add("logs/test.log", rotation="10 MB", retention="30 days")
    
    def create_test_data(self):
        """创建测试数据"""
        logger.info("创建测试数据...")
        
        # 销售数据
        sales_data = {
            'date': pd.date_range('2023-01-01', periods=365, freq='D'),
            'region': np.random.choice(['北京', '上海', '广州', '深圳', '杭州'], 365),
            'product': np.random.choice(['产品A', '产品B', '产品C', '产品D'], 365),
            'sales_amount': np.random.normal(10000, 3000, 365),
            'quantity': np.random.randint(50, 500, 365),
            'customer_count': np.random.randint(10, 100, 365)
        }
        
        sales_df = pd.DataFrame(sales_data)
        sales_df['sales_amount'] = np.maximum(sales_df['sales_amount'], 0)  # 确保非负
        
        # 员工数据
        employee_data = {
            'employee_id': range(1, 101),
            'name': [f'员工{i}' for i in range(1, 101)],
            'department': np.random.choice(['销售', '技术', '市场', '人事', '财务'], 100),
            'salary': np.random.normal(8000, 2000, 100),
            'age': np.random.randint(22, 60, 100),
            'experience_years': np.random.randint(0, 20, 100),
            'performance_score': np.random.uniform(3.0, 5.0, 100)
        }
        
        employee_df = pd.DataFrame(employee_data)
        employee_df['salary'] = np.maximum(employee_df['salary'], 3000)  # 确保最低工资
        
        # 保存测试数据
        sales_df.to_csv('data/test_sales.csv', index=False)
        employee_df.to_csv('data/test_employees.csv', index=False)
        
        # 加载到引擎
        engine.load_data('data/test_sales.csv', 'csv', 'test_sales')
        engine.load_data('data/test_employees.csv', 'csv', 'test_employees')
        
        logger.info("测试数据创建完成")
        return 'test_sales', 'test_employees'
    
    async def test_intent_understanding(self):
        """测试意图理解"""
        logger.info("测试意图理解智能体...")
        
        test_queries = [
            "帮我分析一下销售数据，看看各地区的销售趋势",
            "显示员工工资的分布情况",
            "创建一个柱状图展示各部门人数",
            "查询销售额最高的产品",
            "智能推荐一些分析方案"
        ]
        
        agent = coordinator.agents['intent_understanding']
        results = []
        
        for query in test_queries:
            try:
                result = await agent.process(query)
                results.append({
                    'query': query,
                    'intent': result.get('intent'),
                    'confidence': result.get('confidence'),
                    'entities': result.get('entities'),
                    'success': 'error' not in result
                })
                logger.info(f"查询: {query[:30]}... -> 意图: {result.get('intent')}")
            except Exception as e:
                logger.error(f"意图理解测试失败: {e}")
                results.append({
                    'query': query,
                    'error': str(e),
                    'success': False
                })
        
        return results
    
    async def test_task_decomposition(self):
        """测试任务分解"""
        logger.info("测试任务分解智能体...")
        
        # 模拟意图结果
        intent_result = {
            'intent': 'data_analysis',
            'confidence': 0.8,
            'entities': {'data_source': ['sales']},
            'parameters': {}
        }
        
        agent = coordinator.agents['task_decomposition']
        
        try:
            result = await agent.process(intent_result)
            logger.info(f"任务分解完成: {result.get('complexity')}")
            return {
                'success': 'error' not in result,
                'complexity': result.get('complexity'),
                'template': result.get('selected_template'),
                'plan_length': len(result.get('execution_plan', [])),
                'result': result
            }
        except Exception as e:
            logger.error(f"任务分解测试失败: {e}")
            return {'success': False, 'error': str(e)}
    
    async def test_data_processing(self):
        """测试数据处理"""
        logger.info("测试数据处理智能体...")
        
        # 创建测试任务
        task_plan = {
            'execution_plan': [
                {'type': 'analyze', 'params': {'analysis_type': 'basic'}},
                {'type': 'groupby', 'params': {'group_columns': ['region'], 'agg_functions': {'sales_amount': ['mean', 'sum']}}},
                {'type': 'visualize', 'params': {'chart_type': 'bar'}}
            ],
            'dataset_id': 'test_sales',
            'complexity': 'medium'
        }
        
        agent = coordinator.agents['data_processing']
        
        try:
            result = await agent.process(task_plan)
            success_blocks = result.get('task_summary', {}).get('successful_blocks', 0)
            total_blocks = result.get('task_summary', {}).get('total_blocks', 0)
            
            logger.info(f"数据处理完成: {success_blocks}/{total_blocks} 成功")
            return {
                'success': result.get('success', False),
                'successful_blocks': success_blocks,
                'total_blocks': total_blocks,
                'result': result
            }
        except Exception as e:
            logger.error(f"数据处理测试失败: {e}")
            return {'success': False, 'error': str(e)}
    
    async def test_visualization(self):
        """测试可视化"""
        logger.info("测试可视化智能体...")
        
        # 模拟处理结果
        processing_result = {
            'successful_results': [
                {
                    'block_config': {'type': 'analyze'},
                    'result': {
                        'data': engine.datasets['test_sales']['data'],
                        'details': {}
                    }
                }
            ]
        }
        
        agent = coordinator.agents['visualization']
        
        try:
            result = await agent.process(processing_result)
            chart_count = result.get('summary', {}).get('total_charts', 0)
            
            logger.info(f"可视化完成: {chart_count} 个图表")
            return {
                'success': 'error' not in result,
                'chart_count': chart_count,
                'recommended_charts': result.get('recommended_charts', []),
                'result': result
            }
        except Exception as e:
            logger.error(f"可视化测试失败: {e}")
            return {'success': False, 'error': str(e)}
    
    async def test_coordinator(self):
        """测试协调器"""
        logger.info("测试智能体协调器...")
        
        test_queries = [
            "分析销售数据中各地区的平均销售额",
            "创建员工部门分布的饼图",
            "智能推荐一些数据分析方案"
        ]
        
        results = []
        
        for query in test_queries:
            try:
                result = await coordinator.process_query(query, dataset_id='test_sales')
                results.append({
                    'query': query,
                    'success': result.get('success', False),
                    'workflow': result.get('workflow_info', {}).get('workflow_name'),
                    'processing_time': result.get('processing_info', {}).get('total_processing_time'),
                    'error': result.get('error')
                })
                logger.info(f"协调器测试: {query[:30]}... -> {'成功' if result.get('success') else '失败'}")
            except Exception as e:
                logger.error(f"协调器测试失败: {e}")
                results.append({
                    'query': query,
                    'success': False,
                    'error': str(e)
                })
        
        return results
    
    def test_fastmcp_engine(self):
        """测试FastMCP引擎"""
        logger.info("测试FastMCP引擎...")
        
        # 测试数据加载
        try:
            load_result = engine.load_data('iris', 'sk-learn', 'test_iris')
            if 'error' not in load_result:
                logger.info("数据加载测试成功")
                
                # 测试数据分析
                analysis_result = engine._analyze_block(
                    engine.datasets['test_iris']['data'],
                    {'analysis_type': 'basic'},
                    'test_analysis'
                )
                
                # 测试可视化
                viz_result = engine._visualize_block(
                    engine.datasets['test_iris']['data'],
                    {'chart_type': 'histogram', 'x_column': 'sepal length (cm)'},
                    'test_viz'
                )
                
                return {
                    'data_loading': 'error' not in load_result,
                    'data_analysis': 'error' not in analysis_result,
                    'visualization': 'error' not in viz_result,
                    'load_result': load_result,
                    'analysis_result': analysis_result,
                    'viz_result': viz_result
                }
            else:
                return {'error': load_result['error']}
                
        except Exception as e:
            logger.error(f"FastMCP引擎测试失败: {e}")
            return {'success': False, 'error': str(e)}
    
    async def run_all_tests(self):
        """运行所有测试"""
        logger.info("开始运行系统测试...")
        
        # 创建测试数据
        dataset_ids = self.create_test_data()
        
        test_results = {
            'timestamp': datetime.now().isoformat(),
            'test_data': dataset_ids,
            'tests': {}
        }
        
        # 运行各项测试
        test_results['tests']['fastmcp_engine'] = self.test_fastmcp_engine()
        test_results['tests']['intent_understanding'] = await self.test_intent_understanding()
        test_results['tests']['task_decomposition'] = await self.test_task_decomposition()
        test_results['tests']['data_processing'] = await self.test_data_processing()
        test_results['tests']['visualization'] = await self.test_visualization()
        test_results['tests']['coordinator'] = await self.test_coordinator()
        
        # 计算总体结果
        total_tests = 0
        passed_tests = 0
        
        for test_name, test_result in test_results['tests'].items():
            if isinstance(test_result, dict) and 'success' in test_result:
                total_tests += 1
                if test_result['success']:
                    passed_tests += 1
            elif isinstance(test_result, list):
                # 对于列表结果（如意图理解测试），检查每个项目
                for item in test_result:
                    if isinstance(item, dict) and 'success' in item:
                        total_tests += 1
                        if item['success']:
                            passed_tests += 1
        
        test_results['summary'] = {
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'failed_tests': total_tests - passed_tests,
            'success_rate': round(passed_tests / total_tests * 100, 2) if total_tests > 0 else 0
        }
        
        # 保存测试结果
        with open('logs/test_results.json', 'w', encoding='utf-8') as f:
            json.dump(test_results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"测试完成: {passed_tests}/{total_tests} 通过 ({test_results['summary']['success_rate']}%)")
        
        return test_results


async def main():
    """主测试函数"""
    print("🧪 智能数据问答分析系统 - 功能测试")
    print("=" * 50)
    
    # 创建测试目录
    import os
    os.makedirs('data', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    # 运行测试
    tester = SystemTester()
    results = await tester.run_all_tests()
    
    # 显示测试结果
    print("\n📊 测试结果摘要:")
    print(f"总测试数: {results['summary']['total_tests']}")
    print(f"通过测试: {results['summary']['passed_tests']}")
    print(f"失败测试: {results['summary']['failed_tests']}")
    print(f"成功率: {results['summary']['success_rate']}%")
    
    if results['summary']['success_rate'] >= 80:
        print("\n✅ 系统测试通过！")
    else:
        print("\n❌ 系统测试存在问题，请检查日志。")
    
    print(f"\n📝 详细测试结果已保存到: logs/test_results.json")


if __name__ == "__main__":
    asyncio.run(main())