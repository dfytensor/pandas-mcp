#!/usr/bin/env python3
"""
智能数据问答分析系统 - 功能演示脚本
展示系统的核心功能
"""

import asyncio
import sys
import os

# 添加项目路径
sys.path.append('.')

from core.enhanced_fastmcp import engine
from core.agent_coordinator import coordinator
from core.config import AVAILABLE_DATASETS


async def demo_intent_understanding():
    """演示意图理解功能"""
    print("\n🤖 意图理解演示")
    print("-" * 50)
    
    test_queries = [
        "帮我分析一下销售数据，看看各地区的销售趋势",
        "创建员工部门分布的柱状图", 
        "智能推荐一些数据分析方案",
        "查询销售额最高的产品"
    ]
    
    for query in test_queries:
        print(f"\n用户查询: {query}")
        result = await coordinator.agents['intent_understanding'].process(query)
        print(f"识别意图: {result.get('intent', '未知')}")
        print(f"置信度: {result.get('confidence', 0):.2f}")
        print(f"实体: {result.get('entities', {})}")


async def demo_data_processing():
    """演示数据处理功能"""
    print("\n📊 数据处理演示")
    print("-" * 50)
    
    # 加载示例数据
    print("加载iris数据集...")
    result = engine.load_data('iris', 'sk-learn', 'demo_iris')
    if 'error' not in result:
        print(f"✅ 数据加载成功: {result['data_shape']}")
        
        # 执行数据分析
        print("\n执行数据分析...")
        analysis_result = engine._analyze_block(
            engine.datasets['demo_iris']['data'],
            {'analysis_type': 'basic'},
            'demo_analysis'
        )
        
        if 'error' not in analysis_result:
            print("✅ 数据分析完成")
            details = analysis_result.get('details', {})
            if 'info' in details:
                info = details['info']
                print(f"   数据形状: {info['shape']}")
                print(f"   列数: {len(info['columns'])}")
                print(f"   内存使用: {info.get('memory_usage_mb', 0):.2f} MB")
        else:
            print(f"❌ 分析失败: {analysis_result['error']}")
    else:
        print(f"❌ 数据加载失败: {result['error']}")


async def demo_coordinator():
    """演示智能体协调器"""
    print("\n🎯 智能体协调演示")
    print("-" * 50)
    
    # 先加载数据
    engine.load_data('iris', 'sk-learn', 'demo_coordinator')
    
    test_query = "分析iris数据集中各品种的特征分布"
    print(f"用户查询: {test_query}")
    
    result = await coordinator.process_query(test_query, dataset_id='demo_coordinator')
    
    if result.get('success'):
        print("✅ 查询处理成功")
        
        intent_info = result.get('intent_analysis', {})
        print(f"   识别意图: {intent_info.get('primary_intent', '未知')}")
        print(f"   置信度: {intent_info.get('confidence', 0):.2f}")
        
        workflow_info = result.get('workflow_info', {})
        print(f"   工作流: {workflow_info.get('workflow_name', '未知')}")
        print(f"   执行步骤: {workflow_info.get('steps_executed', 0)}")
        print(f"   处理时间: {workflow_info.get('execution_time', 0):.2f}秒")
        
        # 显示数据洞察
        insights = result.get('data_insights', [])
        if insights:
            print("   数据洞察:")
            for insight in insights:
                print(f"   • {insight}")
        
        # 显示建议
        recommendations = result.get('recommendations', [])
        if recommendations:
            print("   建议:")
            for rec in recommendations:
                print(f"   • {rec}")
    else:
        print(f"❌ 查询处理失败: {result.get('error', '未知错误')}")


def demo_visualization():
    """演示可视化功能"""
    print("\n📈 可视化演示")
    print("-" * 50)
    
    # 确保有数据
    if 'demo_iris' not in engine.datasets:
        engine.load_data('iris', 'sk-learn', 'demo_iris')
    
    df = engine.datasets['demo_iris']['data']
    print(f"数据形状: {df.shape}")
    print(f"列名: {list(df.columns)}")
    
    # 创建可视化配置
    viz_config = {
        'chart_type': 'histogram',
        'x_column': 'sepal length (cm)',
        'title': '鸢尾花萼片长度分布'
    }
    
    print(f"\n创建{viz_config['chart_type']}图表...")
    viz_result = engine._visualize_block(df, viz_config, 'demo_viz')
    
    if 'error' not in viz_result:
        print("✅ 可视化创建成功")
        details = viz_result.get('details', {})
        print(f"   图表类型: {details.get('chart_type', '未知')}")
        print(f"   X轴列: {details.get('x_column', '未知')}")
        print(f"   标题: {details.get('title', '未知')}")
    else:
        print(f"❌ 可视化创建失败: {viz_result['error']}")


def show_system_info():
    """显示系统信息"""
    print("\n📋 系统信息")
    print("=" * 50)
    print(f"应用名称: 智能数据问答分析系统")
    print(f"版本: 1.0.0")
    print(f"可用数据集: {len(AVAILABLE_DATASETS)}")
    
    print("\n核心组件:")
    print("✅ FastMCP引擎")
    print("✅ 意图理解智能体")
    print("✅ 任务分解智能体")
    print("✅ 数据处理智能体")
    print("✅ 可视化智能体")
    print("✅ SQL查询智能体")
    print("✅ 智能体协调器")
    print("✅ FastAPI服务")
    print("✅ Gradio界面")
    
    print(f"\n当前数据集数量: {len(engine.datasets)}")
    print(f"智能体数量: {len(coordinator.agents)}")
    
    # 显示数据集信息
    if engine.datasets:
        print("\n已加载的数据集:")
        for dataset_id, info in engine.datasets.items():
            df = info['data']
            print(f"   • {dataset_id}: {df.shape[0]}行 x {df.shape[1]}列")


async def main():
    """主演示函数"""
    print("🎉 智能数据问答分析系统 - 功能演示")
    print("=" * 60)
    
    # 显示系统信息
    show_system_info()
    
    # 演示各项功能
    await demo_intent_understanding()
    await demo_data_processing()
    await demo_coordinator()
    demo_visualization()
    
    print("\n🎊 演示完成!")
    print("=" * 60)
    print("💡 使用说明:")
    print("1. 运行 'python main.py' 启动完整系统")
    print("2. 访问 http://localhost:7860 使用Web界面")
    print("3. 访问 http://localhost:8000/docs 查看API文档")
    print("\n🚀 感谢使用智能数据问答分析系统!")


if __name__ == "__main__":
    # 创建必要的目录
    os.makedirs('data', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    # 运行演示
    asyncio.run(main())