#!/usr/bin/env python3
"""
智能数据问答分析系统 - 核心智能体实现
基于用户提供的FastMCP代码进行扩展
"""

import pandas as pd
import numpy as np
import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncio
from abc import ABC, abstractmethod
from loguru import logger
import jieba
import jieba.posseg as pseg
from concurrent.futures import ThreadPoolExecutor
import time


class BaseAgent(ABC):
    """智能体基类"""
    
    def __init__(self, name: str):
        self.name = name
        self.capabilities = []
        self.context = {}
        self.executor = ThreadPoolExecutor(max_workers=2)
        self.processing_stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "average_processing_time": 0.0
        }
    
    @abstractmethod
    async def process(self, input_data: Any) -> Dict[str, Any]:
        """处理输入数据"""
        pass
    
    def log(self, message: str, level: str = "INFO"):
        """记录日志"""
        timestamp = datetime.now().isoformat()
        logger.log(level, f"[{self.name}] {message}")
    
    def update_stats(self, processing_time: float, success: bool):
        """更新处理统计"""
        self.processing_stats["total_requests"] += 1
        if success:
            self.processing_stats["successful_requests"] += 1
        else:
            self.processing_stats["failed_requests"] += 1
        
        # 更新平均处理时间
        total = self.processing_stats["total_requests"]
        current_avg = self.processing_stats["average_processing_time"]
        self.processing_stats["average_processing_time"] = (current_avg * (total - 1) + processing_time) / total
    
    def get_stats(self) -> Dict[str, Any]:
        """获取处理统计"""
        return self.processing_stats.copy()


class IntentUnderstandingAgent(BaseAgent):
    """意图理解智能体"""
    
    def __init__(self):
        super().__init__("意图理解智能体")
        
        # 中文意图模式
        self.intent_patterns = {
            'data_query': {
                'keywords': ['查询', '显示', '找出', '统计', '多少', '哪些', '什么', '哪个', '列表'],
                'weight': 1.0
            },
            'data_analysis': {
                'keywords': ['分析', '对比', '趋势', '相关性', '分布', '特征', '评估', '检查'],
                'weight': 1.2
            },
            'visualization': {
                'keywords': ['图表', '可视化', '画图', '展示', '图形', '柱状图', '折线图', '散点图'],
                'weight': 1.1
            },
            'data_cleaning': {
                'keywords': ['清洗', '清理', '去重', '填充', '缺失', '异常', '修正'],
                'weight': 1.0
            },
            'aggregation': {
                'keywords': ['汇总', '分组', '聚合', '求和', '平均', '计数', '最大值', '最小值'],
                'weight': 1.1
            },
            'comparison': {
                'keywords': ['比较', '对比', '差异', '哪个更好', '高于', '低于', '增长', '下降'],
                'weight': 1.3
            },
            'filtering': {
                'keywords': ['过滤', '筛选', '条件', '大于', '小于', '等于', '包含'],
                'weight': 1.0
            },
            'smart_recommendation': {
                'keywords': ['建议', '推荐', '智能', '自动', '分析一下', '看看'],
                'weight': 1.4
            }
        }
        
        # 实体模式
        self.entity_patterns = {
            'data_source': ['数据库', '表', '文件', 'CSV', 'Excel', 'JSON', 'sqlite'],
            'time_reference': ['今天', '昨天', '本周', '上月', '今年', '去年', '最近'],
            'comparison_words': ['比', '相对于', '与...相比', '增长', '下降'],
            'aggregation_words': ['总计', '平均', '最大', '最小', '中位数'],
            'chart_types': ['柱状图', '折线图', '散点图', '饼图', '热力图', '箱线图']
        }
        
        # 数据操作词
        self.action_words = {
            'load': ['加载', '导入', '读取', '上传'],
            'save': ['保存', '存储', '导出'],
            'show': ['显示', '查看', '展示'],
            'delete': ['删除', '移除', '清理']
        }
        
        # 初始化jieba
        jieba.initialize()
        self.log("意图理解智能体初始化完成")
    
    async def process(self, user_input: str) -> Dict[str, Any]:
        """解析用户意图"""
        start_time = time.time()
        try:
            self.log(f"解析用户输入: {user_input}")
            
            # 1. 文本预处理
            processed_text = self._preprocess_text(user_input)
            
            # 2. 意图识别
            intent_scores = self._recognize_intent(processed_text)
            
            # 3. 实体提取
            entities = self._extract_entities(processed_text)
            
            # 4. 参数解析
            parameters = self._extract_parameters(processed_text)
            
            # 5. 置信度评估
            confidence = self._calculate_confidence(intent_scores, entities, parameters)
            
            # 6. 生成处理建议
            suggestions = self._generate_suggestions(intent_scores, entities)
            
            result = {
                'intent': max(intent_scores.items(), key=lambda x: x[1])[0] if intent_scores else 'data_query',
                'confidence': confidence,
                'intent_scores': intent_scores,
                'entities': entities,
                'parameters': parameters,
                'suggestions': suggestions,
                'original_text': user_input,
                'processed_text': processed_text,
                'processing_info': {
                    'processing_time': time.time() - start_time,
                    'timestamp': datetime.now().isoformat()
                }
            }
            
            self.update_stats(time.time() - start_time, True)
            self.log(f"意图解析完成: {result['intent']} (置信度: {confidence:.2f})")
            return result
            
        except Exception as e:
            self.log(f"意图解析失败: {str(e)}", "ERROR")
            self.update_stats(time.time() - start_time, False)
            return {
                'error': f"意图解析失败: {str(e)}",
                'original_text': user_input,
                'processing_info': {
                    'processing_time': time.time() - start_time,
                    'timestamp': datetime.now().isoformat()
                }
            }
    
    def _preprocess_text(self, text: str) -> str:
        """文本预处理"""
        # 去除多余空格和标点
        text = re.sub(r'\s+', ' ', text.strip())
        # 统一标点符号
        text = text.replace('，', ',').replace('。', '.').replace('？', '?')
        return text
    
    def _recognize_intent(self, text: str) -> Dict[str, float]:
        """识别用户意图"""
        intent_scores = {}
        
        for intent, pattern in self.intent_patterns.items():
            score = 0
            keywords = pattern['keywords']
            weight = pattern['weight']
            
            # 计算关键词匹配分数
            for keyword in keywords:
                if keyword in text:
                    score += 1
            
            # 计算词性匹配分数
            words = jieba.lcut(text)
            for word in words:
                if word in keywords:
                    score += 0.5
            
            # 应用权重
            final_score = score * weight
            if final_score > 0:
                intent_scores[intent] = final_score
        
        return intent_scores
    
    def _extract_entities(self, text: str) -> Dict[str, List[str]]:
        """提取实体"""
        entities = {}
        
        # 使用jieba进行词性标注
        words = pseg.lcut(text)
        
        for entity_type, patterns in self.entity_patterns.items():
            found_entities = []
            for pattern in patterns:
                if pattern in text:
                    found_entities.append(pattern)
            
            # 从分词结果中提取实体
            for word, flag in words:
                if flag in ['n', 'nr', 'nz']:  # 名词
                    if word in patterns:
                        found_entities.append(word)
            
            if found_entities:
                entities[entity_type] = list(set(found_entities))  # 去重
        
        return entities
    
    def _extract_parameters(self, text: str) -> Dict[str, Any]:
        """提取参数"""
        parameters = {}
        
        # 提取数值
        numbers = re.findall(r'\d+(?:\.\d+)?', text)
        if numbers:
            parameters['numbers'] = [float(n) for n in numbers]
        
        # 提取百分比
        percentages = re.findall(r'\d+(?:\.\d+)?%', text)
        if percentages:
            parameters['percentages'] = [float(p.rstrip('%')) for p in percentages]
        
        # 提取列名（假设为中文字符串）
        column_matches = re.findall(r'[列字段变量指标].*?[是为]', text)
        if column_matches:
            parameters['column_references'] = column_matches
        
        # 提取条件表达式
        condition_patterns = [
            r'大于(\d+(?:\.\d+)?)',
            r'小于(\d+(?:\.\d+)?)',
            r'等于(\d+(?:\.\d+)?)',
            r'包含(.+?)[，。]',
        ]
        
        conditions = []
        for pattern in condition_patterns:
            matches = re.findall(pattern, text)
            conditions.extend(matches)
        
        if conditions:
            parameters['conditions'] = conditions
        
        return parameters
    
    def _calculate_confidence(self, intent_scores: Dict[str, float], entities: Dict[str, List[str]], parameters: Dict[str, Any]) -> float:
        """计算置信度"""
        base_confidence = 0.5
        
        # 基于意图分数调整
        if intent_scores:
            max_score = max(intent_scores.values())
            intent_confidence = min(max_score / 3.0, 1.0)  # 标准化到0-1
        else:
            intent_confidence = 0.0
        
        # 基于实体数量调整
        entity_confidence = min(len(entities) / 3.0, 1.0)
        
        # 基于参数数量调整
        param_confidence = min(len(parameters) / 2.0, 1.0)
        
        # 综合置信度
        confidence = (base_confidence + intent_confidence * 0.4 + entity_confidence * 0.3 + param_confidence * 0.3)
        return min(confidence, 1.0)
    
    def _generate_suggestions(self, intent_scores: Dict[str, float], entities: Dict[str, List[str]]) -> List[str]:
        """生成处理建议"""
        suggestions = []
        
        primary_intent = max(intent_scores.items(), key=lambda x: x[1])[0] if intent_scores else 'data_query'
        
        if primary_intent == 'data_query':
            suggestions.append("建议使用基础查询功能")
            if 'data_source' in entities:
                suggestions.append("检测到数据源引用，建议先加载数据")
        
        elif primary_intent == 'data_analysis':
            suggestions.append("建议进行数据分析")
            suggestions.append("可以生成统计摘要和相关性分析")
        
        elif primary_intent == 'visualization':
            suggestions.append("建议创建可视化图表")
            if 'chart_types' in entities:
                chart_type = entities['chart_types'][0]
                suggestions.append(f"检测到图表类型: {chart_type}")
        
        elif primary_intent == 'smart_recommendation':
            suggestions.append("建议使用智能推荐功能")
            suggestions.append("系统将自动分析数据特征并推荐分析方案")
        
        return suggestions


class TaskDecompositionAgent(BaseAgent):
    """任务分解智能体"""
    
    def __init__(self):
        super().__init__("任务分解智能体")
        
        # 任务模板
        self.task_templates = {
            'basic_analysis': {
                'description': '基础数据分析',
                'blocks': [
                    {'type': 'analyze', 'params': {'analysis_type': 'basic'}},
                    {'type': 'visualize', 'params': {'chart_type': 'histogram'}}
                ]
            },
            'correlation_analysis': {
                'description': '相关性分析',
                'blocks': [
                    {'type': 'analyze', 'params': {'analysis_type': 'correlation'}},
                    {'type': 'visualize', 'params': {'chart_type': 'heatmap'}}
                ]
            },
            'group_analysis': {
                'description': '分组分析',
                'blocks': [
                    {'type': 'groupby', 'params': {'group_columns': ['category'], 'agg_functions': {'value': ['mean', 'count']}}},
                    {'type': 'visualize', 'params': {'chart_type': 'bar'}}
                ]
            },
            'trend_analysis': {
                'description': '趋势分析',
                'blocks': [
                    {'type': 'filter', 'params': {'conditions': []}},
                    {'type': 'groupby', 'params': {'group_columns': ['date'], 'agg_functions': {'value': ['mean']}}},
                    {'type': 'visualize', 'params': {'chart_type': 'line'}}
                ]
            },
            'comparison_analysis': {
                'description': '对比分析',
                'blocks': [
                    {'type': 'analyze', 'params': {'analysis_type': 'basic'}},
                    {'type': 'groupby', 'params': {'group_columns': ['group'], 'agg_functions': {'value': ['mean', 'std']}}},
                    {'type': 'visualize', 'params': {'chart_type': 'bar'}}
                ]
            },
            'data_cleaning': {
                'description': '数据清洗',
                'blocks': [
                    {'type': 'clean', 'params': {'operations': [
                        {'method': 'drop_duplicates'},
                        {'method': 'fillna', 'value': 0}
                    ]}}
                ]
            },
            'smart_recommendation': {
                'description': '智能推荐分析',
                'blocks': [
                    {'type': 'smart_recommend', 'params': {}}
                ]
            }
        }
        
        self.log("任务分解智能体初始化完成")
    
    async def process(self, intent_result: Dict[str, Any]) -> Dict[str, Any]:
        """任务分解"""
        start_time = time.time()
        try:
            self.log(f"开始任务分解: {intent_result['intent']}")
            
            # 1. 分析任务复杂度
            complexity = self._analyze_complexity(intent_result)
            
            # 2. 选择任务模板
            selected_template = self._select_template(intent_result)
            
            # 3. 生成执行计划
            execution_plan = self._generate_execution_plan(intent_result, selected_template, complexity)
            
            # 4. 优化执行顺序
            optimized_plan = self._optimize_pipeline(execution_plan)
            
            # 5. 生成任务依赖关系
            dependencies = self._analyze_dependencies(optimized_plan)
            
            result = {
                'complexity': complexity,
                'selected_template': selected_template,
                'execution_plan': optimized_plan,
                'dependencies': dependencies,
                'estimated_time': self._estimate_execution_time(optimized_plan),
                'input_intent': intent_result,
                'processing_info': {
                    'processing_time': time.time() - start_time,
                    'timestamp': datetime.now().isoformat()
                }
            }
            
            self.update_stats(time.time() - start_time, True)
            self.log(f"任务分解完成: {len(optimized_plan)} 个步骤")
            return result
            
        except Exception as e:
            self.log(f"任务分解失败: {str(e)}", "ERROR")
            self.update_stats(time.time() - start_time, False)
            return {
                'error': f"任务分解失败: {str(e)}",
                'input_intent': intent_result
            }
    
    def _analyze_complexity(self, intent_result: Dict[str, Any]) -> str:
        """分析任务复杂度"""
        intent = intent_result.get('intent', 'data_query')
        confidence = intent_result.get('confidence', 0.5)
        entities = intent_result.get('entities', {})
        parameters = intent_result.get('parameters', {})
        
        # 复杂度评估规则
        complexity_score = 0
        
        # 基于意图的复杂度
        complex_intents = ['data_analysis', 'comparison_analysis', 'smart_recommendation']
        if intent in complex_intents:
            complexity_score += 2
        
        # 基于置信度
        if confidence > 0.8:
            complexity_score += 1
        
        # 基于实体数量
        complexity_score += len(entities) // 2
        
        # 基于参数数量
        complexity_score += len(parameters)
        
        if complexity_score <= 2:
            return 'simple'
        elif complexity_score <= 5:
            return 'medium'
        else:
            return 'complex'
    
    def _select_template(self, intent_result: Dict[str, Any]) -> str:
        """选择任务模板"""
        intent = intent_result.get('intent', 'data_query')
        entities = intent_result.get('entities', {})
        
        # 基于意图选择模板
        template_mapping = {
            'data_query': 'basic_analysis',
            'data_analysis': 'correlation_analysis',
            'visualization': 'basic_analysis',
            'aggregation': 'group_analysis',
            'comparison': 'comparison_analysis',
            'data_cleaning': 'data_cleaning',
            'smart_recommendation': 'smart_recommendation'
        }
        
        # 检查是否有特殊要求
        if 'chart_types' in entities:
            if '热力图' in entities['chart_types']:
                return 'correlation_analysis'
            elif '折线图' in entities['chart_types']:
                return 'trend_analysis'
        
        return template_mapping.get(intent, 'basic_analysis')
    
    def _generate_execution_plan(self, intent_result: Dict[str, Any], template: str, complexity: str) -> List[Dict]:
        """生成执行计划"""
        base_plan = self.task_templates[template]['blocks'].copy()
        
        # 根据复杂度调整计划
        if complexity == 'simple':
            # 简化计划，只保留核心步骤
            if len(base_plan) > 2:
                base_plan = base_plan[:2]
        elif complexity == 'complex':
            # 复杂计划，增加详细分析
            if 'analyze' not in [block['type'] for block in base_plan]:
                base_plan.insert(0, {'type': 'analyze', 'params': {'analysis_type': 'basic'}})
        
        # 根据实体和参数调整计划
        entities = intent_result.get('entities', {})
        parameters = intent_result.get('parameters', {})
        
        # 如果有数据源信息，添加数据加载步骤
        if 'data_source' in entities:
            # 数据加载通常在外部处理，这里只是标记
            pass
        
        # 如果有特定的可视化要求，调整可视化参数
        if 'chart_types' in entities:
            for block in base_plan:
                if block['type'] == 'visualize':
                    chart_type = entities['chart_types'][0]
                    block['params']['chart_type'] = self._map_chart_type(chart_type)
        
        return base_plan
    
    def _map_chart_type(self, chart_type: str) -> str:
        """映射图表类型"""
        mapping = {
            '柱状图': 'bar',
            '折线图': 'line',
            '散点图': 'scatter',
            '饼图': 'pie',
            '热力图': 'heatmap',
            '箱线图': 'box'
        }
        return mapping.get(chart_type, 'bar')
    
    def _optimize_pipeline(self, plan: List[Dict]) -> List[Dict]:
        """优化执行顺序"""
        # 基本的优化规则
        optimized_plan = []
        
        for block in plan:
            block_type = block['type']
            
            # 数据清洗通常应该在前面
            if block_type == 'clean' and not any(b['type'] == 'clean' for b in optimized_plan):
                optimized_plan.insert(0, block)
            # 分析通常在清洗后
            elif block_type == 'analyze':
                # 找到合适的位置插入
                insert_index = len(optimized_plan)
                for i, existing_block in enumerate(optimized_plan):
                    if existing_block['type'] in ['visualize', 'groupby']:
                        insert_index = i
                        break
                optimized_plan.insert(insert_index, block)
            # 分组通常在分析后
            elif block_type == 'groupby':
                # 找到分析块之后的位置
                insert_index = len(optimized_plan)
                for i, existing_block in enumerate(optimized_plan):
                    if existing_block['type'] == 'analyze':
                        insert_index = i + 1
                        break
                optimized_plan.insert(insert_index, block)
            # 可视化通常在最后
            elif block_type == 'visualize':
                optimized_plan.append(block)
            # 智能推荐可以单独执行
            elif block_type == 'smart_recommend':
                optimized_plan.append(block)
            else:
                optimized_plan.append(block)
        
        return optimized_plan
    
    def _analyze_dependencies(self, plan: List[Dict]) -> Dict[str, List[str]]:
        """分析任务依赖关系"""
        dependencies = {}
        
        for i, block in enumerate(plan):
            block_name = f"block_{i+1}_{block['type']}"
            deps = []
            
            # 分析依赖关系
            if block['type'] == 'analyze':
                # 分析依赖于数据
                deps = ['data_loaded']
            elif block['type'] == 'groupby':
                # 分组依赖于分析或数据
                deps = ['data_loaded']
            elif block['type'] == 'visualize':
                # 可视化依赖于前面的分析结果
                deps = [f"block_{j+1}_{plan[j]['type']}" for j in range(i) if plan[j]['type'] in ['analyze', 'groupby']]
            elif block['type'] == 'clean':
                # 清洗是第一步
                deps = ['data_loaded']
            
            dependencies[block_name] = deps
        
        return dependencies
    
    def _estimate_execution_time(self, plan: List[Dict]) -> float:
        """估算执行时间（秒）"""
        base_time = 0.5  # 每个块的基础时间
        
        time_estimates = {
            'clean': 1.0,
            'filter': 0.5,
            'transform': 1.0,
            'analyze': 2.0,
            'groupby': 1.5,
            'join': 3.0,
            'visualize': 2.5,
            'smart_recommend': 3.0
        }
        
        total_time = 0
        for block in plan:
            block_type = block['type']
            total_time += time_estimates.get(block_type, base_time)
        
        return total_time


class DataProcessingAgent(BaseAgent):
    """数据处理智能体"""
    
    def __init__(self):
        super().__init__("数据处理智能体")
        from core.enhanced_fastmcp import engine
        self.mcp_engine = engine
        self.processing_cache = {}
        self.log("数据处理智能体初始化完成")
    
    async def process(self, task_plan: Dict[str, Any]) -> Dict[str, Any]:
        """执行数据处理任务"""
        start_time = time.time()
        try:
            self.log(f"开始执行数据处理任务: {len(task_plan['execution_plan'])} 个步骤")
            
            execution_plan = task_plan['execution_plan']
            dataset_id = task_plan.get('dataset_id')
            processing_results = []
            
            # 逐个执行积木
            for i, block_config in enumerate(execution_plan):
                block_name = f"block_{i+1}_{block_config['type']}"
                self.log(f"执行积木 {i+1}: {block_config['type']}")
                
                # 检查缓存
                cache_key = f"{dataset_id}_{block_config['type']}_{hash(str(block_config['params']))}"
                if cache_key in self.processing_cache:
                    result = self.processing_cache[cache_key]
                    self.log(f"缓存命中: {block_name}")
                else:
                    # 执行积木
                    result = await self._execute_block_async(block_config, dataset_id)
                    
                    # 缓存结果
                    if 'error' not in result:
                        self.processing_cache[cache_key] = result
                
                processing_results.append({
                    'block_name': block_name,
                    'block_config': block_config,
                    'result': result,
                    'execution_order': i + 1
                })
                
                # 检查是否出错
                if 'error' in result:
                    self.log(f"积木执行失败: {result['error']}", "ERROR")
                    break
            
            # 整合结果
            final_result = self._integrate_results(processing_results, task_plan)
            
            self.update_stats(time.time() - start_time, True)
            self.log(f"数据处理完成: {len(processing_results)} 个步骤")
            return final_result
            
        except Exception as e:
            self.log(f"数据处理失败: {str(e)}", "ERROR")
            self.update_stats(time.time() - start_time, False)
            return {
                'error': f"数据处理失败: {str(e)}",
                'task_plan': task_plan
            }
    
    async def _execute_block_async(self, block_config: Dict, dataset_id: str) -> Dict[str, Any]:
        """异步执行单个积木"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self.executor,
            self._execute_block_sync,
            block_config,
            dataset_id
        )
    
    def _execute_block_sync(self, block_config: Dict, dataset_id: str) -> Dict[str, Any]:
        """同步执行单个积木"""
        try:
            block_type = block_config['type']
            params = block_config.get('params', {})
            
            # 根据积木类型调用相应的MCP引擎方法
            if block_type == 'clean':
                return self.mcp_engine._clean_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            elif block_type == 'filter':
                return self.mcp_engine._filter_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            elif block_type == 'transform':
                return self.mcp_engine._transform_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            elif block_type == 'analyze':
                return self.mcp_engine._analyze_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            elif block_type == 'groupby':
                return self.mcp_engine._groupby_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            elif block_type == 'join':
                return self.mcp_engine._join_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            elif block_type == 'visualize':
                return self.mcp_engine._visualize_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            elif block_type == 'smart_recommend':
                return self.mcp_engine._smart_recommend_block(
                    self.mcp_engine.datasets[dataset_id]['data'], 
                    params, 
                    f"block_{block_type}"
                )
            else:
                return {'error': f"不支持的积木类型: {block_type}"}
                
        except Exception as e:
            return {'error': f"积木执行失败: {str(e)}"}
    
    def _integrate_results(self, processing_results: List[Dict], task_plan: Dict[str, Any]) -> Dict[str, Any]:
        """整合处理结果"""
        successful_results = []
        failed_results = []
        total_execution_time = 0
        
        for result in processing_results:
            if 'error' not in result['result']:
                successful_results.append(result)
            else:
                failed_results.append(result)
            
            total_execution_time += result['result'].get('execution_time', 0)
        
        # 生成最终结果
        final_result = {
            'success': len(failed_results) == 0,
            'task_summary': {
                'total_blocks': len(processing_results),
                'successful_blocks': len(successful_results),
                'failed_blocks': len(failed_results),
                'total_execution_time': total_execution_time,
                'complexity': task_plan.get('complexity', 'unknown')
            },
            'processing_results': processing_results,
            'successful_results': successful_results,
            'failed_results': failed_results,
            'data_insights': self._extract_data_insights(successful_results),
            'recommendations': self._generate_recommendations(successful_results, failed_results)
        }
        
        return final_result
    
    def _extract_data_insights(self, successful_results: List[Dict]) -> List[str]:
        """提取数据洞察"""
        insights = []
        
        for result in successful_results:
            block_type = result['block_config']['type']
            block_result = result['result']
            
            if block_type == 'analyze':
                details = block_result.get('details', {})
                if 'correlation_matrix' in details:
                    insights.append("检测到数值变量间存在相关性")
                if 'outliers' in details:
                    insights.append("数据中存在异常值，建议进一步检查")
            
            elif block_type == 'groupby':
                details = block_result.get('details', {})
                if 'groups_count' in details:
                    groups_count = details['groups_count']
                    insights.append(f"数据分为 {groups_count} 个组别")
            
            elif block_type == 'smart_recommend':
                details = block_result.get('details', {})
                if 'recommendations' in details:
                    rec_count = len(details['recommendations'])
                    insights.append(f"系统推荐了 {rec_count} 种分析方案")
        
        return insights
    
    def _generate_recommendations(self, successful_results: List[Dict], failed_results: List[Dict]) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if failed_results:
            recommendations.append("部分处理步骤失败，建议检查参数配置")
        
        if len(successful_results) == 0:
            recommendations.append("没有成功的处理结果，建议重新检查数据")
        
        # 基于成功的处理结果给出建议
        for result in successful_results:
            block_type = result['block_config']['type']
            if block_type == 'smart_recommend':
                details = result['result'].get('details', {})
                if 'recommendations' in details:
                    recommendations.append("可以使用智能推荐的分析方案")
        
        return recommendations


class VisualizationAgent(BaseAgent):
    """可视化智能体"""
    
    def __init__(self):
        super().__init__("可视化智能体")
        self.chart_configs = {
            'bar': {
                'description': '柱状图',
                'best_for': ['分类数据', '数量对比'],
                'data_requirements': ['分类列', '数值列']
            },
            'line': {
                'description': '折线图',
                'best_for': ['时间序列', '趋势分析'],
                'data_requirements': ['时间列', '数值列']
            },
            'scatter': {
                'description': '散点图',
                'best_for': ['相关性分析', '分布查看'],
                'data_requirements': ['两个数值列']
            },
            'pie': {
                'description': '饼图',
                'best_for': ['比例展示', '构成分析'],
                'data_requirements': ['分类列', '数值列']
            },
            'histogram': {
                'description': '直方图',
                'best_for': ['分布分析', '频率统计'],
                'data_requirements': ['单个数值列']
            },
            'box': {
                'description': '箱线图',
                'best_for': ['异常值检测', '分布比较'],
                'data_requirements': ['数值列']
            },
            'heatmap': {
                'description': '热力图',
                'best_for': ['相关性矩阵', '密度分布'],
                'data_requirements': ['数值数据']
            }
        }
        self.log("可视化智能体初始化完成")
    
    async def process(self, processing_result: Dict[str, Any]) -> Dict[str, Any]:
        """创建可视化"""
        start_time = time.time()
        try:
            self.log("开始创建可视化")
            
            # 1. 分析数据特征
            data_info = self._analyze_data_for_visualization(processing_result)
            
            # 2. 推荐图表类型
            recommended_charts = self._recommend_chart_types(data_info, processing_result)
            
            # 3. 生成图表配置
            chart_configs = []
            for chart_type in recommended_charts:
                config = self._generate_chart_config(chart_type, data_info, processing_result)
                if config:
                    chart_configs.append(config)
            
            # 4. 创建可视化
            visualizations = []
            for config in chart_configs:
                viz = await self._create_visualization(config, processing_result)
                if viz:
                    visualizations.append(viz)
            
            result = {
                'data_info': data_info,
                'recommended_charts': recommended_charts,
                'chart_configs': chart_configs,
                'visualizations': visualizations,
                'summary': {
                    'total_charts': len(visualizations),
                    'chart_types': [viz['chart_type'] for viz in visualizations]
                }
            }
            
            self.update_stats(time.time() - start_time, True)
            self.log(f"可视化创建完成: {len(visualizations)} 个图表")
            return result
            
        except Exception as e:
            self.log(f"可视化创建失败: {str(e)}", "ERROR")
            self.update_stats(time.time() - start_time, False)
            return {
                'error': f"可视化创建失败: {str(e)}",
                'processing_result': processing_result
            }
    
    def _analyze_data_for_visualization(self, processing_result: Dict[str, Any]) -> Dict[str, Any]:
        """分析数据特征用于可视化"""
        data_info = {
            'has_numeric_data': False,
            'has_categorical_data': False,
            'has_time_data': False,
            'data_size': 0,
            'numeric_columns': [],
            'categorical_columns': [],
            'time_columns': [],
            'data_quality': 'unknown'
        }
        
        # 从处理结果中提取数据信息
        for result in processing_result.get('successful_results', []):
            block_result = result['result']
            if 'data' in block_result:
                df = block_result['data']
                if hasattr(df, 'shape'):
                    data_info['data_size'] = df.shape[0]
                    
                    # 检查数值列
                    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
                    if numeric_cols:
                        data_info['has_numeric_data'] = True
                        data_info['numeric_columns'] = numeric_cols
                    
                    # 检查分类列
                    categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
                    if categorical_cols:
                        data_info['has_categorical_data'] = True
                        data_info['categorical_columns'] = categorical_cols
                    
                    # 检查时间列
                    time_cols = []
                    for col in df.columns:
                        if df[col].dtype == 'datetime64[ns]' or 'time' in col.lower() or 'date' in col.lower():
                            time_cols.append(col)
                    
                    if time_cols:
                        data_info['has_time_data'] = True
                        data_info['time_columns'] = time_cols
                    
                    break  # 只分析第一个有效数据
        
        # 评估数据质量
        if data_info['data_size'] == 0:
            data_info['data_quality'] = 'no_data'
        elif data_info['has_numeric_data'] and data_info['has_categorical_data']:
            data_info['data_quality'] = 'good'
        elif data_info['has_numeric_data'] or data_info['has_categorical_data']:
            data_info['data_quality'] = 'fair'
        else:
            data_info['data_quality'] = 'poor'
        
        return data_info
    
    def _recommend_chart_types(self, data_info: Dict[str, Any], processing_result: Dict[str, Any]) -> List[str]:
        """推荐图表类型"""
        recommendations = []
        
        # 基于数据特征推荐
        if data_info['has_numeric_data'] and data_info['has_categorical_data']:
            recommendations.extend(['bar', 'box'])
        
        if data_info['has_numeric_data'] and len(data_info['numeric_columns']) >= 2:
            recommendations.append('scatter')
        
        if data_info['has_time_data'] and data_info['has_numeric_data']:
            recommendations.append('line')
        
        if data_info['has_categorical_data'] and data_info['has_numeric_data']:
            recommendations.append('pie')
        
        if data_info['has_numeric_data'] and len(data_info['numeric_columns']) == 1:
            recommendations.append('histogram')
        
        if data_info['has_numeric_data'] and len(data_info['numeric_columns']) >= 2:
            recommendations.append('heatmap')
        
        # 基于处理结果推荐
        for result in processing_result.get('successful_results', []):
            block_type = result['block_config']['type']
            if block_type == 'correlation_analysis':
                recommendations.append('heatmap')
            elif block_type == 'group_analysis':
                recommendations.append('bar')
            elif block_type == 'trend_analysis':
                recommendations.append('line')
        
        # 去重并限制数量
        unique_recommendations = list(dict.fromkeys(recommendations))  # 保持顺序的去重
        return unique_recommendations[:3]  # 最多返回3个推荐
    
    def _generate_chart_config(self, chart_type: str, data_info: Dict[str, Any], processing_result: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """生成图表配置"""
        config = {
            'chart_type': chart_type,
            'title': self.chart_configs[chart_type]['description'],
            'x_column': None,
            'y_column': None,
            'color_column': None,
            'additional_params': {}
        }
        
        # 根据图表类型设置配置
        if chart_type == 'bar':
            if data_info['categorical_columns'] and data_info['numeric_columns']:
                config['x_column'] = data_info['categorical_columns'][0]
                config['y_column'] = data_info['numeric_columns'][0]
                if len(data_info['categorical_columns']) > 1:
                    config['color_column'] = data_info['categorical_columns'][1]
        
        elif chart_type == 'line':
            if data_info['time_columns'] and data_info['numeric_columns']:
                config['x_column'] = data_info['time_columns'][0]
                config['y_column'] = data_info['numeric_columns'][0]
        
        elif chart_type == 'scatter':
            if len(data_info['numeric_columns']) >= 2:
                config['x_column'] = data_info['numeric_columns'][0]
                config['y_column'] = data_info['numeric_columns'][1]
                if data_info['categorical_columns']:
                    config['color_column'] = data_info['categorical_columns'][0]
        
        elif chart_type == 'pie':
            if data_info['categorical_columns'] and data_info['numeric_columns']:
                config['x_column'] = data_info['categorical_columns'][0]
                config['y_column'] = data_info['numeric_columns'][0]
        
        elif chart_type == 'histogram':
            if data_info['numeric_columns']:
                config['x_column'] = data_info['numeric_columns'][0]
                if data_info['categorical_columns']:
                    config['color_column'] = data_info['categorical_columns'][0]
        
        elif chart_type == 'box':
            if data_info['numeric_columns']:
                config['y_column'] = data_info['numeric_columns'][0]
                if data_info['categorical_columns']:
                    config['x_column'] = data_info['categorical_columns'][0]
        
        elif chart_type == 'heatmap':
            config['additional_params']['chart_type'] = 'heatmap'
        
        # 检查配置是否完整
        if chart_type in ['bar', 'line', 'scatter', 'pie', 'histogram', 'box']:
            if not config.get('x_column') and not config.get('y_column'):
                return None  # 配置不完整，返回None
        
        return config
    
    async def _create_visualization(self, config: Dict[str, Any], processing_result: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """创建可视化"""
        try:
            # 从处理结果中获取数据
            df = None
            for result in processing_result.get('successful_results', []):
                block_result = result['result']
                if 'data' in block_result:
                    df = block_result['data']
                    break
            
            if df is None:
                return None
            
            # 创建可视化积木配置
            visualize_block = {
                'type': 'visualize',
                'params': config
            }
            
            # 调用MCP引擎创建可视化
            from core.enhanced_fastmcp import engine
            viz_result = engine._visualize_block(df, config, f"viz_{config['chart_type']}")
            
            if 'error' not in viz_result:
                return {
                    'chart_type': config['chart_type'],
                    'config': config,
                    'result': viz_result,
                    'html_content': viz_result.get('details', {}).get('figure_html')
                }
            else:
                return None
                
        except Exception as e:
            self.log(f"创建可视化失败: {str(e)}", "ERROR")
            return None


class SQLQueryAgent(BaseAgent):
    """SQL查询智能体"""
    
    def __init__(self):
        super().__init__("SQL查询智能体")
        self.sql_templates = {
            'basic_select': "SELECT {columns} FROM {table}",
            'where_filter': "SELECT {columns} FROM {table} WHERE {conditions}",
            'group_analysis': "SELECT {group_columns}, {agg_functions} FROM {table} GROUP BY {group_columns}",
            'order_by': "SELECT {columns} FROM {table} ORDER BY {order_columns} {order_direction}",
            'join_tables': "SELECT {columns} FROM {table1} {join_type} JOIN {table2} ON {join_condition}"
        }
        self.log("SQL查询智能体初始化完成")
    
    async def process(self, intent_result: Dict[str, Any]) -> Dict[str, Any]:
        """生成SQL查询"""
        start_time = time.time()
        try:
            self.log("开始生成SQL查询")
            
            # 1. 分析查询需求
            query_requirements = self._analyze_query_requirements(intent_result)
            
            # 2. 生成SQL语句
            sql_statements = self._generate_sql_statements(query_requirements)
            
            # 3. 优化查询
            optimized_sql = self._optimize_sql(sql_statements)
            
            # 4. 生成查询解释
            query_explanation = self._explain_query(optimized_sql, query_requirements)
            
            result = {
                'query_requirements': query_requirements,
                'generated_sql': optimized_sql,
                'sql_statements': sql_statements,
                'query_explanation': query_explanation,
                'estimated_performance': self._estimate_performance(optimized_sql),
                'alternative_queries': self._generate_alternatives(query_requirements)
            }
            
            self.update_stats(time.time() - start_time, True)
            self.log("SQL查询生成完成")
            return result
            
        except Exception as e:
            self.log(f"SQL查询生成失败: {str(e)}", "ERROR")
            self.update_stats(time.time() - start_time, False)
            return {
                'error': f"SQL查询生成失败: {str(e)}",
                'intent_result': intent_result
            }
    
    def _analyze_query_requirements(self, intent_result: Dict[str, Any]) -> Dict[str, Any]:
        """分析查询需求"""
        requirements = {
            'query_type': 'select',
            'tables': [],
            'columns': [],
            'conditions': [],
            'group_by': [],
            'order_by': [],
            'aggregations': [],
            'joins': []
        }
        
        intent = intent_result.get('intent', 'data_query')
        entities = intent_result.get('entities', {})
        parameters = intent_result.get('parameters', {})
        
        # 基于意图确定查询类型
        if intent == 'aggregation':
            requirements['query_type'] = 'aggregate'
            requirements['aggregations'] = ['COUNT', 'SUM', 'AVG']
        elif intent == 'data_analysis':
            requirements['query_type'] = 'analysis'
        elif intent == 'comparison':
            requirements['query_type'] = 'comparison'
        
        # 提取表信息
        if 'data_source' in entities:
            requirements['tables'] = entities['data_source']
        
        # 提取列信息
        if 'column_references' in parameters:
            requirements['columns'] = parameters['column_references']
        
        # 提取条件
        if 'conditions' in parameters:
            requirements['conditions'] = parameters['conditions']
        
        return requirements
    
    def _generate_sql_statements(self, requirements: Dict[str, Any]) -> List[str]:
        """生成SQL语句"""
        sql_statements = []
        
        query_type = requirements['query_type']
        
        if query_type == 'select':
            sql = self._generate_basic_select(requirements)
        elif query_type == 'aggregate':
            sql = self._generate_aggregate_query(requirements)
        elif query_type == 'analysis':
            sql = self._generate_analysis_query(requirements)
        elif query_type == 'comparison':
            sql = self._generate_comparison_query(requirements)
        else:
            sql = self._generate_basic_select(requirements)
        
        sql_statements.append(sql)
        return sql_statements
    
    def _generate_basic_select(self, requirements: Dict[str, Any]) -> str:
        """生成基础SELECT查询"""
        columns = requirements['columns'] if requirements['columns'] else ['*']
        tables = requirements['tables'] if requirements['tables'] else ['table_name']
        conditions = requirements['conditions']
        
        sql = f"SELECT {', '.join(columns)} FROM {', '.join(tables)}"
        
        if conditions:
            sql += f" WHERE {', '.join(conditions)}"
        
        return sql
    
    def _generate_aggregate_query(self, requirements: Dict[str, Any]) -> str:
        """生成聚合查询"""
        group_columns = requirements['group_by'] if requirements['group_by'] else ['category']
        aggregations = requirements['aggregations']
        tables = requirements['tables'] if requirements['tables'] else ['table_name']
        
        agg_functions = []
        for agg in aggregations:
            if agg == 'COUNT':
                agg_functions.append('COUNT(*)')
            elif agg == 'SUM':
                agg_functions.append('SUM(value)')
            elif agg == 'AVG':
                agg_functions.append('AVG(value)')
        
        sql = f"SELECT {', '.join(group_columns)}, {', '.join(agg_functions)}"
        sql += f" FROM {', '.join(tables)}"
        sql += f" GROUP BY {', '.join(group_columns)}"
        
        return sql
    
    def _generate_analysis_query(self, requirements: Dict[str, Any]) -> str:
        """生成分析查询"""
        # 基础分析查询
        return self._generate_basic_select(requirements)
    
    def _generate_comparison_query(self, requirements: Dict[str, Any]) -> str:
        """生成对比查询"""
        # 对比查询通常需要多个子查询或JOIN
        base_query = self._generate_basic_select(requirements)
        return f"-- 对比分析查询\n{base_query}\n-- 可以添加更多对比逻辑"
    
    def _optimize_sql(self, sql_statements: List[str]) -> str:
        """优化SQL语句"""
        optimized_statements = []
        
        for sql in sql_statements:
            # 简单的优化规则
            optimized_sql = sql
            
            # 添加索引建议
            if 'WHERE' in optimized_sql:
                optimized_sql += "\n-- 建议在WHERE条件的列上创建索引"
            
            # 添加性能提示
            if 'SELECT *' in optimized_sql:
                optimized_sql = optimized_sql.replace('SELECT *', 'SELECT specific_columns')
                optimized_sql += "\n-- 建议指定具体列名而不是SELECT *"
            
            optimized_statements.append(optimized_sql)
        
        return '\n'.join(optimized_statements)
    
    def _explain_query(self, sql: str, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """生成查询解释"""
        return {
            'query_purpose': self._determine_query_purpose(requirements),
            'complexity': self._assess_query_complexity(sql),
            'performance_impact': self._assess_performance_impact(sql),
            'data_access_pattern': self._determine_data_access_pattern(requirements),
            'optimization_suggestions': self._generate_optimization_suggestions(sql)
        }
    
    def _determine_query_purpose(self, requirements: Dict[str, Any]) -> str:
        """确定查询目的"""
        query_type = requirements['query_type']
        purpose_mapping = {
            'select': '数据检索',
            'aggregate': '数据聚合分析',
            'analysis': '数据分析',
            'comparison': '数据对比'
        }
        return purpose_mapping.get(query_type, '数据查询')
    
    def _assess_query_complexity(self, sql: str) -> str:
        """评估查询复杂度"""
        complexity_score = 0
        
        if 'JOIN' in sql:
            complexity_score += 2
        if 'GROUP BY' in sql:
            complexity_score += 1
        if 'WHERE' in sql:
            complexity_score += 1
        if 'ORDER BY' in sql:
            complexity_score += 1
        
        if complexity_score <= 1:
            return '简单'
        elif complexity_score <= 3:
            return '中等'
        else:
            return '复杂'
    
    def _assess_performance_impact(self, sql: str) -> str:
        """评估性能影响"""
        if 'SELECT *' in sql:
            return '高 - 使用了SELECT *'
        elif 'JOIN' in sql:
            return '中等 - 包含表连接'
        elif 'GROUP BY' in sql:
            return '中等 - 包含分组操作'
        else:
            return '低 - 简单查询'
    
    def _determine_data_access_pattern(self, requirements: Dict[str, Any]) -> str:
        """确定数据访问模式"""
        if requirements['group_by']:
            return '聚合访问'
        elif requirements['conditions']:
            return '条件访问'
        else:
            return '全表扫描'
    
    def _generate_optimization_suggestions(self, sql: str) -> List[str]:
        """生成优化建议"""
        suggestions = []
        
        if 'SELECT *' in sql:
            suggestions.append('指定具体列名，避免使用SELECT *')
        
        if 'WHERE' in sql and 'INDEX' not in sql.upper():
            suggestions.append('在WHERE条件的列上创建索引')
        
        if 'JOIN' in sql:
            suggestions.append('确保连接键有适当的索引')
        
        if 'GROUP BY' in sql:
            suggestions.append('考虑在GROUP BY的列上创建索引')
        
        return suggestions
    
    def _estimate_performance(self, sql: str) -> Dict[str, Any]:
        """估算查询性能"""
        return {
            'estimated_time': '1-10秒',
            'data_volume_impact': '中等',
            'index_usage': '需要检查',
            'bottleneck_risk': '中等'
        }
    
    def _generate_alternatives(self, requirements: Dict[str, Any]) -> List[str]:
        """生成替代查询方案"""
        alternatives = []
        
        # 基于pandas的替代方案
        pandas_alternative = """
# Pandas替代方案
import pandas as pd
df = pd.read_sql_query(sql_query, connection)
result = df.groupby('column').agg({'value': 'sum'})
"""
        alternatives.append(pandas_alternative)
        
        return alternatives