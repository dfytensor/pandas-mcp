#!/usr/bin/env python3
"""
智能数据问答分析系统 - 主启动文件
启动整个系统（FastAPI后端 + Gradio前端）
"""

import asyncio
import uvicorn
import threading
import time
import signal
import sys
from loguru import logger
from typing import Optional

# 导入配置
from core.config import API_CONFIG, FRONTEND_CONFIG

# 导入应用组件
from api.main import app as fastapi_app
from frontend.gradio_interface import create_gradio_app


class SystemLauncher:
    """系统启动器"""
    
    def __init__(self):
        self.fastapi_server = None
        self.gradio_app = None
        self.running = False
        self.processes = []
        
        # 设置日志
        logger.add("logs/system.log", rotation="10 MB", retention="30 days")
        logger.info("系统启动器初始化完成")
    
    def setup_signal_handlers(self):
        """设置信号处理器"""
        def signal_handler(signum, frame):
            logger.info(f"接收到信号 {signum}，正在关闭系统...")
            self.shutdown()
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    def start_fastapi_server(self):
        """启动FastAPI服务器"""
        try:
            logger.info(f"启动FastAPI服务器: http://{API_CONFIG['host']}:{API_CONFIG['port']}")
            
            config = uvicorn.Config(
                app=fastapi_app,
                host=API_CONFIG['host'],
                port=API_CONFIG['port'],
                log_level="info",
                access_log=True
            )
            
            self.fastapi_server = uvicorn.Server(config)
            
            # 在新线程中运行FastAPI
            api_thread = threading.Thread(
                target=self.fastapi_server.run,
                daemon=True
            )
            api_thread.start()
            
            self.processes.append(("FastAPI", api_thread))
            logger.info("FastAPI服务器启动成功")
            
        except Exception as e:
            logger.error(f"FastAPI服务器启动失败: {str(e)}")
            raise
    
    def start_gradio_server(self):
        """启动Gradio服务器"""
        try:
            logger.info(f"启动Gradio前端: http://{FRONTEND_CONFIG['server_name']}:{FRONTEND_CONFIG['server_port']}")
            
            # 创建Gradio应用
            self.gradio_app = create_gradio_app()
            
            # 在新线程中运行Gradio
            gradio_thread = threading.Thread(
                target=self._run_gradio,
                daemon=True
            )
            gradio_thread.start()
            
            self.processes.append(("Gradio", gradio_thread))
            logger.info("Gradio服务器启动成功")
            
        except Exception as e:
            logger.error(f"Gradio服务器启动失败: {str(e)}")
            raise
    
    def _run_gradio(self):
        """运行Gradio应用"""
        try:
            self.gradio_app.launch(
                server_name=FRONTEND_CONFIG['server_name'],
                server_port=FRONTEND_CONFIG['server_port'],
                share=FRONTEND_CONFIG['share'],
                debug=FRONTEND_CONFIG['debug'],
                show_error=True,
                quiet=False
            )
        except Exception as e:
            logger.error(f"Gradio运行失败: {str(e)}")
    
    def start_system(self):
        """启动整个系统"""
        try:
            logger.info("=" * 60)
            logger.info("🚀 启动智能数据问答分析系统")
            logger.info("=" * 60)
            
            # 设置信号处理器
            self.setup_signal_handlers()
            
            # 启动FastAPI服务器
            self.start_fastapi_server()
            
            # 等待FastAPI启动
            time.sleep(2)
            
            # 启动Gradio服务器
            self.start_gradio_server()
            
            # 等待Gradio启动
            time.sleep(2)
            
            self.running = True
            
            # 显示启动信息
            self._print_startup_info()
            
            # 保持主线程运行
            self._keep_running()
            
        except Exception as e:
            logger.error(f"系统启动失败: {str(e)}")
            self.shutdown()
            raise
    
    def _print_startup_info(self):
        """打印启动信息"""
        print("\n" + "=" * 80)
        print("🎉 智能数据问答分析系统启动成功！")
        print("=" * 80)
        print(f"📡 API服务地址: http://{API_CONFIG['host']}:{API_CONFIG['port']}")
        print(f"🌐 前端界面地址: http://{FRONTEND_CONFIG['server_name']}:{FRONTEND_CONFIG['server_port']}")
        print(f"📚 API文档地址: http://{API_CONFIG['host']}:{API_CONFIG['port']}/docs")
        print("=" * 80)
        print("💡 系统功能:")
        print("   • 🤖 智能自然语言问答")
        print("   • 📊 多智能体数据分析")
        print("   • 🎨 智能可视化生成")
        print("   • 📁 多格式数据支持")
        print("   • 🔄 实时处理状态")
        print("=" * 80)
        print("⏹️  按 Ctrl+C 停止系统")
        print("=" * 80)
    
    def _keep_running(self):
        """保持系统运行"""
        try:
            while self.running:
                # 检查进程状态
                for name, process in self.processes:
                    if not process.is_alive():
                        logger.warning(f"{name} 进程已停止")
                        self.running = False
                        break
                
                if not self.running:
                    break
                
                time.sleep(1)
                
        except KeyboardInterrupt:
            logger.info("接收到中断信号")
        except Exception as e:
            logger.error(f"系统运行错误: {str(e)}")
        finally:
            self.shutdown()
    
    def shutdown(self):
        """关闭系统"""
        if not self.running:
            return
        
        logger.info("正在关闭系统...")
        self.running = False
        
        # 关闭FastAPI服务器
        if self.fastapi_server:
            try:
                self.fastapi_server.should_exit = True
                logger.info("FastAPI服务器已关闭")
            except Exception as e:
                logger.error(f"关闭FastAPI服务器失败: {str(e)}")
        
        # 等待所有进程结束
        for name, process in self.processes:
            try:
                if process.is_alive():
                    logger.info(f"等待 {name} 进程结束...")
                    process.join(timeout=5)
                    if process.is_alive():
                        logger.warning(f"{name} 进程未正常结束")
            except Exception as e:
                logger.error(f"关闭 {name} 进程失败: {str(e)}")
        
        logger.info("系统已完全关闭")
        print("\n👋 感谢使用智能数据问答分析系统！")


def main():
    """主函数"""
    try:
        # 创建必要的目录
        import os
        os.makedirs("data", exist_ok=True)
        os.makedirs("logs", exist_ok=True)
        
        # 创建并启动系统
        launcher = SystemLauncher()
        launcher.start_system()
        
    except KeyboardInterrupt:
        logger.info("用户中断，系统退出")
    except Exception as e:
        logger.error(f"系统启动失败: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()