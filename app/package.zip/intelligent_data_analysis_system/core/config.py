#!/usr/bin/env python3
"""
智能数据问答分析系统 - 配置管理
"""

import os
from typing import Dict, Any

# 应用配置
APP_CONFIG = {
    "name": "智能数据问答分析系统",
    "version": "1.0.0",
    "description": "基于多智能体的智能数据分析系统",
    "author": "MiniMax Agent"
}

# FastAPI配置
API_CONFIG = {
    "host": "0.0.0.0",
    "port": 8000,
    "debug": True,
    "title": "智能数据分析API",
    "description": "提供智能数据分析和问答功能的REST API",
    "version": "1.0.0"
}

# Gradio前端配置
FRONTEND_CONFIG = {
    "server_name": "0.0.0.0",
    "server_port": 7860,
    "share": False,
    "debug": True,
    "title": "智能数据问答分析系统"
}

# 数据集配置
DATASET_CONFIG = {
    "default_timeout": 3600,  # 1小时
    "max_datasets": 10,
    "cleanup_interval": 300,  # 5分钟
    "supported_types": ["sk-learn", "sqlite", "csv", "json", "excel"],
    "default_path": "data/"
}

# 可用sklearn数据集
AVAILABLE_DATASETS = {
    "iris": "鸢尾花数据集",
    "wine": "红酒数据集", 
    "breast_cancer": "乳腺癌数据集",
    "diabetes": "糖尿病数据集",
    "california_housing": "加州房价数据集"
}

# SQLite配置
SQLITE_CONFIG = {
    "default_path": "data/analysis.db",
    "backup_path": "data/backups/",
    "max_connections": 10
}

# 智能体配置
AGENT_CONFIG = {
    "max_concurrent_agents": 5,
    "timeout_per_agent": 300,  # 5分钟
    "retry_attempts": 3,
    "cache_ttl": 1800  # 30分钟
}

# 日志配置
LOG_CONFIG = {
    "level": "INFO",
    "format": "{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} | {message}",
    "rotation": "10 MB",
    "retention": "30 days"
}

# 自然语言处理配置
NLP_CONFIG = {
    "intent_threshold": 0.7,
    "confidence_threshold": 0.6,
    "supported_languages": ["zh", "en"],
    "default_language": "zh"
}

# 可视化配置
VISUALIZATION_CONFIG = {
    "default_chart_type": "bar",
    "supported_types": ["bar", "line", "scatter", "pie", "heatmap", "box"],
    "max_data_points": 10000,
    "figure_size": (10, 6)
}

# 缓存配置
CACHE_CONFIG = {
    "backend": "memory",  # memory, redis, file
    "ttl": 3600,  # 1小时
    "max_size": 1000
}

# 安全配置
SECURITY_CONFIG = {
    "allowed_file_types": [".csv", ".json", ".xlsx", ".xls", ".db"],
    "max_file_size": 100 * 1024 * 1024,  # 100MB
    "allowed_origins": ["*"]
}