#!/usr/bin/env python3
"""
智能数据问答分析系统 - 智能体协调器
协调各个专业智能体的工作流程
"""

import asyncio
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
from loguru import logger

from agents.intelligent_agents import (
    BaseAgent, 
    IntentUnderstandingAgent, 
    TaskDecompositionAgent, 
    DataProcessingAgent, 
    VisualizationAgent, 
    SQLQueryAgent
)
from .config import AGENT_CONFIG


class WorkflowEngine:
    """工作流引擎"""
    
    def __init__(self):
        self.workflows = {
            'simple_query': {
                'description': '简单查询工作流',
                'steps': ['intent_understanding', 'data_processing'],
                'estimated_time': 5
            },
            'complex_analysis': {
                'description': '复杂分析工作流',
                'steps': ['intent_understanding', 'task_decomposition', 'data_processing', 'visualization'],
                'estimated_time': 15
            },
            'smart_recommendation': {
                'description': '智能推荐工作流',
                'steps': ['intent_understanding', 'task_decomposition', 'data_processing', 'visualization'],
                'estimated_time': 20
            },
            'sql_query': {
                'description': 'SQL查询工作流',
                'steps': ['intent_understanding', 'sql_query', 'data_processing'],
                'estimated_time': 10
            },
            'data_cleaning': {
                'description': '数据清洗工作流',
                'steps': ['intent_understanding', 'task_decomposition', 'data_processing'],
                'estimated_time': 8
            }
        }
        logger.info("工作流引擎初始化完成")
    
    def select_workflow(self, intent_result: Dict[str, Any]) -> str:
        """选择合适的工作流"""
        intent = intent_result.get('intent', 'data_query')
        confidence = intent_result.get('confidence', 0.5)
        entities = intent_result.get('entities', {})
        
        # 基于意图选择工作流
        if intent == 'smart_recommendation':
            return 'smart_recommendation'
        elif intent == 'data_cleaning':
            return 'data_cleaning'
        elif intent == 'sql_query' or 'sql' in str(entities).lower():
            return 'sql_query'
        elif confidence > 0.8 and len(intent_result.get('entities', {})) > 2:
            return 'complex_analysis'
        else:
            return 'simple_query'
    
    def get_workflow_info(self, workflow_name: str) -> Dict[str, Any]:
        """获取工作流信息"""
        return self.workflows.get(workflow_name, {})
    
    def validate_workflow(self, workflow_name: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """验证工作流"""
        workflow = self.workflows.get(workflow_name)
        if not workflow:
            return {'valid': False, 'error': f'工作流不存在: {workflow_name}'}
        
        # 检查上下文是否满足工作流要求
        required_context = ['user_input', 'dataset_id']
        missing_context = [key for key in required_context if key not in context]
        
        if missing_context:
            return {
                'valid': False, 
                'error': f'缺少必要上下文: {missing_context}',
                'workflow': workflow
            }
        
        return {'valid': True, 'workflow': workflow}
    
    def estimate_workflow_time(self, workflow_name: str, context: Dict[str, Any]) -> float:
        """估算工作流执行时间"""
        workflow = self.workflows.get(workflow_name, {})
        base_time = workflow.get('estimated_time', 10)
        
        # 根据上下文调整时间估算
        complexity_multiplier = 1.0
        
        if context.get('data_size', 0) > 10000:
            complexity_multiplier *= 1.5
        if context.get('complexity') == 'complex':
            complexity_multiplier *= 1.3
        
        return base_time * complexity_multiplier


class AgentCoordinator:
    """智能体协调器"""
    
    def __init__(self):
        # 初始化各个智能体
        self.agents = {
            'intent_understanding': IntentUnderstandingAgent(),
            'task_decomposition': TaskDecompositionAgent(),
            'data_processing': DataProcessingAgent(),
            'visualization': VisualizationAgent(),
            'sql_query': SQLQueryAgent()
        }
        
        self.workflow_engine = WorkflowEngine()
        self.result_cache = {}
        self.active_sessions = {}
        self.processing_stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'average_processing_time': 0.0,
            'workflow_distribution': {}
        }
        
        logger.info("智能体协调器初始化完成")
    
    async def process_query(self, user_query: str, dataset_id: str = None, session_id: str = None) -> Dict[str, Any]:
        """协调处理用户查询"""
        start_time = time.time()
        session_id = session_id or f"session_{int(time.time())}"
        
        try:
            self.processing_stats['total_requests'] += 1
            logger.info(f"开始处理查询: {user_query[:50]}...")
            
            # 创建会话上下文
            context = {
                'session_id': session_id,
                'user_query': user_query,
                'dataset_id': dataset_id,
                'start_time': start_time,
                'timestamp': datetime.now().isoformat()
            }
            
            # 1. 意图理解
            logger.info("步骤1: 意图理解")
            intent_result = await self.agents['intent_understanding'].process(user_query)
            context['intent_result'] = intent_result
            
            if 'error' in intent_result:
                raise Exception(f"意图理解失败: {intent_result['error']}")
            
            # 2. 选择工作流
            workflow_name = self.workflow_engine.select_workflow(intent_result)
            context['workflow_name'] = workflow_name
            
            logger.info(f"选择工作流: {workflow_name}")
            
            # 验证工作流
            workflow_validation = self.workflow_engine.validate_workflow(workflow_name, context)
            if not workflow_validation['valid']:
                raise Exception(f"工作流验证失败: {workflow_validation['error']}")
            
            # 3. 执行工作流
            workflow_result = await self._execute_workflow(workflow_name, context)
            context['workflow_result'] = workflow_result
            
            # 4. 整合结果
            final_result = self._integrate_results(context, workflow_result)
            
            # 更新统计信息
            processing_time = time.time() - start_time
            self._update_processing_stats(processing_time, True, workflow_name)
            
            # 缓存结果
            self._cache_result(session_id, final_result)
            
            logger.info(f"查询处理完成，耗时: {processing_time:.2f}秒")
            return final_result
            
        except Exception as e:
            processing_time = time.time() - start_time
            self._update_processing_stats(processing_time, False, 'error')
            logger.error(f"查询处理失败: {str(e)}")
            
            return {
                'success': False,
                'error': str(e),
                'processing_time': processing_time,
                'session_id': session_id,
                'suggestions': [
                    "请检查您的查询是否清晰明确",
                    "确保数据已正确加载",
                    "尝试使用更简单的查询语句"
                ]
            }
    
    async def _execute_workflow(self, workflow_name: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """执行工作流"""
        workflow = self.workflow_engine.workflows[workflow_name]
        steps = workflow['steps']
        workflow_results = {}
        
        logger.info(f"执行工作流: {workflow_name}, 步骤数: {len(steps)}")
        
        for i, step in enumerate(steps):
            step_start_time = time.time()
            step_name = f"step_{i+1}_{step}"
            
            try:
                logger.info(f"执行步骤 {i+1}/{len(steps)}: {step}")
                
                if step == 'intent_understanding':
                    # 意图理解已在主流程中完成
                    result = context['intent_result']
                
                elif step == 'task_decomposition':
                    result = await self.agents['task_decomposition'].process(context['intent_result'])
                
                elif step == 'data_processing':
                    # 准备数据处理任务
                    if 'task_plan' not in context:
                        # 如果没有任务计划，创建一个基础计划
                        task_plan = {
                            'execution_plan': [
                                {'type': 'analyze', 'params': {'analysis_type': 'basic'}}
                            ],
                            'dataset_id': context.get('dataset_id'),
                            'complexity': 'simple'
                        }
                        context['task_plan'] = task_plan
                    
                    result = await self.agents['data_processing'].process(context['task_plan'])
                
                elif step == 'visualization':
                    if 'processing_result' in context:
                        result = await self.agents['visualization'].process(context['processing_result'])
                    else:
                        result = {'error': '没有可用的处理结果进行可视化'}
                
                elif step == 'sql_query':
                    result = await self.agents['sql_query'].process(context['intent_result'])
                
                else:
                    result = {'error': f'未知的工作流步骤: {step}'}
                
                workflow_results[step] = {
                    'result': result,
                    'execution_time': time.time() - step_start_time,
                    'success': 'error' not in result
                }
                
                # 将结果存储到上下文中，供后续步骤使用
                if step == 'task_decomposition':
                    context['task_plan'] = result
                elif step == 'data_processing':
                    context['processing_result'] = result
                elif step == 'visualization':
                    context['visualization_result'] = result
                elif step == 'sql_query':
                    context['sql_result'] = result
                
                logger.info(f"步骤 {step} 执行完成，耗时: {time.time() - step_start_time:.2f}秒")
                
            except Exception as e:
                logger.error(f"步骤 {step} 执行失败: {str(e)}")
                workflow_results[step] = {
                    'result': {'error': str(e)},
                    'execution_time': time.time() - step_start_time,
                    'success': False
                }
        
        return {
            'workflow_name': workflow_name,
            'steps_executed': len(steps),
            'results': workflow_results,
            'successful_steps': len([r for r in workflow_results.values() if r['success']]),
            'failed_steps': len([r for r in workflow_results.values() if not r['success']]),
            'total_execution_time': time.time() - context['start_time']
        }
    
    def _integrate_results(self, context: Dict[str, Any], workflow_result: Dict[str, Any]) -> Dict[str, Any]:
        """整合所有结果"""
        intent_result = context['intent_result']
        workflow_results = workflow_result['results']
        
        # 整合成功的结果
        successful_results = {}
        failed_results = {}
        
        for step, step_result in workflow_results.items():
            if step_result['success']:
                successful_results[step] = step_result['result']
            else:
                failed_results[step] = step_result['result']
        
        # 生成最终响应
        final_response = {
            'success': len(failed_results) == 0,
            'session_id': context['session_id'],
            'user_query': context['user_query'],
            'intent_analysis': {
                'primary_intent': intent_result.get('intent'),
                'confidence': intent_result.get('confidence'),
                'entities': intent_result.get('entities', {}),
                'suggestions': intent_result.get('suggestions', [])
            },
            'workflow_info': {
                'workflow_name': workflow_result['workflow_name'],
                'steps_executed': workflow_result['steps_executed'],
                'successful_steps': workflow_result['successful_steps'],
                'execution_time': workflow_result['total_execution_time']
            },
            'results': {
                'successful_results': successful_results,
                'failed_results': failed_results
            },
            'data_insights': self._extract_data_insights(successful_results),
            'recommendations': self._generate_recommendations(successful_results, failed_results),
            'next_actions': self._suggest_next_actions(intent_result, successful_results),
            'processing_info': {
                'total_processing_time': time.time() - context['start_time'],
                'timestamp': datetime.now().isoformat()
            }
        }
        
        return final_response
    
    def _extract_data_insights(self, successful_results: Dict[str, Any]) -> List[str]:
        """提取数据洞察"""
        insights = []
        
        # 从各个智能体的结果中提取洞察
        for step, result in successful_results.items():
            if step == 'data_processing' and 'data_insights' in result:
                insights.extend(result['data_insights'])
            elif step == 'visualization' and 'summary' in result:
                insights.append(f"生成了 {result['summary']['total_charts']} 个可视化图表")
            elif step == 'sql_query' and 'query_explanation' in result:
                insights.append(f"生成了SQL查询: {result['query_explanation']['query_purpose']}")
        
        return insights
    
    def _generate_recommendations(self, successful_results: Dict[str, Any], failed_results: Dict[str, Any]) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if failed_results:
            recommendations.append("部分处理步骤失败，建议检查参数配置")
        
        # 基于成功的处理结果给出建议
        for step, result in successful_results.items():
            if step == 'task_decomposition' and 'execution_plan' in result:
                recommendations.append("任务已成功分解，可以按计划执行")
            elif step == 'data_processing' and 'recommendations' in result:
                recommendations.extend(result['recommendations'])
            elif step == 'visualization' and 'recommended_charts' in result:
                recommendations.append(f"推荐使用: {', '.join(result['recommended_charts'])}")
        
        return recommendations
    
    def _suggest_next_actions(self, intent_result: Dict[str, Any], successful_results: Dict[str, Any]) -> List[str]:
        """建议下一步操作"""
        actions = []
        
        intent = intent_result.get('intent', 'data_query')
        
        if intent == 'data_analysis':
            actions.append("可以尝试进行更深入的相关性分析")
            actions.append("建议查看数据的分布特征")
        elif intent == 'visualization':
            actions.append("可以尝试不同类型的图表")
            actions.append("建议调整图表的样式和参数")
        elif intent == 'smart_recommendation':
            actions.append("可以按照推荐的分析方案继续探索")
            actions.append("建议查看智能推荐的具体建议")
        
        # 基于处理结果建议
        if 'visualization' in successful_results:
            actions.append("可以保存或分享生成的图表")
        
        if 'sql_query' in successful_results:
            actions.append("可以执行生成的SQL查询获取详细数据")
        
        return actions
    
    def _cache_result(self, session_id: str, result: Dict[str, Any]):
        """缓存结果"""
        self.result_cache[session_id] = {
            'result': result,
            'timestamp': time.time()
        }
        
        # 清理过期缓存
        if len(self.result_cache) > 100:
            current_time = time.time()
            expired_sessions = [
                sid for sid, cache_info in self.result_cache.items()
                if current_time - cache_info['timestamp'] > 3600  # 1小时过期
            ]
            for sid in expired_sessions:
                del self.result_cache[sid]
    
    def get_cached_result(self, session_id: str) -> Optional[Dict[str, Any]]:
        """获取缓存的结果"""
        if session_id in self.result_cache:
            cache_info = self.result_cache[session_id]
            # 检查是否过期
            if time.time() - cache_info['timestamp'] < 3600:  # 1小时
                return cache_info['result']
            else:
                del self.result_cache[session_id]
        return None
    
    def _update_processing_stats(self, processing_time: float, success: bool, workflow_name: str):
        """更新处理统计"""
        if success:
            self.processing_stats['successful_requests'] += 1
        else:
            self.processing_stats['failed_requests'] += 1
        
        # 更新平均处理时间
        total = self.processing_stats['total_requests']
        current_avg = self.processing_stats['average_processing_time']
        self.processing_stats['average_processing_time'] = (current_avg * (total - 1) + processing_time) / total
        
        # 更新工作流分布
        if workflow_name in self.processing_stats['workflow_distribution']:
            self.processing_stats['workflow_distribution'][workflow_name] += 1
        else:
            self.processing_stats['workflow_distribution'][workflow_name] = 1
    
    def get_processing_stats(self) -> Dict[str, Any]:
        """获取处理统计"""
        return {
            'coordinator_stats': self.processing_stats.copy(),
            'agent_stats': {
                name: agent.get_stats() 
                for name, agent in self.agents.items()
            },
            'workflow_stats': self.workflow_engine.workflows.copy()
        }
    
    async def get_session_status(self, session_id: str) -> Dict[str, Any]:
        """获取会话状态"""
        cached_result = self.get_cached_result(session_id)
        if cached_result:
            return {
                'session_id': session_id,
                'status': 'completed',
                'result': cached_result,
                'cached': True
            }
        else:
            return {
                'session_id': session_id,
                'status': 'not_found',
                'cached': False
            }
    
    def cleanup_sessions(self):
        """清理过期会话"""
        current_time = time.time()
        expired_sessions = [
            session_id for session_id, cache_info in self.result_cache.items()
            if current_time - cache_info['timestamp'] > 3600  # 1小时过期
        ]
        
        for session_id in expired_sessions:
            del self.result_cache[session_id]
        
        logger.info(f"清理了 {len(expired_sessions)} 个过期会话")
        return len(expired_sessions)


# 创建全局协调器实例
coordinator = AgentCoordinator()