#!/usr/bin/env python3
"""
智能数据问答分析系统 - 增强版FastMCP引擎
基于用户提供的FastMCP代码进行扩展和增强
"""

import pandas as pd
import numpy as np
import json
import io
import base64
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
from typing import Dict, Any, List, Optional
import uuid
import time
import asyncio
import threading
from datetime import datetime
import traceback
import sqlite3
import os
from loguru import logger
import pickle
from concurrent.futures import ThreadPoolExecutor
import warnings
warnings.filterwarnings('ignore')

from .config import DATASET_CONFIG, SQLITE_CONFIG, AVAILABLE_DATASETS


class EnhancedPandasBlocksEngine:
    """增强版Pandas积木执行引擎"""
    
    def __init__(self):
        self.datasets = {}  # 存储数据集的字典
        self.current_dataset_id = None
        self.analysis_history = []
        self.processing_cache = {}
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.cleanup_task = None
        
        # 创建数据目录
        os.makedirs(DATASET_CONFIG["default_path"], exist_ok=True)
        os.makedirs(SQLITE_CONFIG["backup_path"], exist_ok=True)
        
        # 启动清理服务
        self._start_cleanup_service()
        
        logger.info("增强版Pandas积木引擎初始化完成")
    
    def load_data(self, data_source: str, data_type_param: str = "auto", dataset_name: str = None) -> Dict[str, Any]:
        """加载数据积木 - 增强版"""
        try:
            df = None
            
            # 如果没有指定数据类型，使用配置中的默认类型
            if data_type_param == "auto":
                data_type_param = DATASET_CONFIG.get("default_type", "csv")

            # 根据数据类型加载数据
            if data_type_param == "sk-learn":
                df = self._load_sklearn_dataset(data_source)
            elif data_type_param == "sqlite":
                df = self._load_sqlite_table(data_source)
            elif data_type_param == "csv":
                if data_source.startswith(("http://", "https://")):
                    df = pd.read_csv(data_source)
                else:
                    df = pd.read_csv(io.StringIO(data_source))
            elif data_type_param == "json":
                df = pd.read_json(io.StringIO(data_source))
            elif data_type_param == "excel":
                df = pd.read_excel(io.BytesIO(data_source.encode() if isinstance(data_source, str) else data_source))
            else:
                # 自动检测类型
                try:
                    df = pd.read_csv(io.StringIO(data_source))
                except:
                    try:
                        df = pd.read_json(io.StringIO(data_source))
                    except:
                        return {"error": f"无法自动检测数据类型: {data_type_param}"}

            # 生成数据集ID
            if not dataset_name:
                dataset_name = f"dataset_{len(self.datasets) + 1}_{datetime.now().strftime('%H%M%S')}"

            self.datasets[dataset_name] = {
                "data": df, 
                "timestamp": time.time(),
                "data_type": data_type_param,
                "source": data_source
            }
            self.current_dataset_id = dataset_name

            # 记录操作历史
            self.analysis_history.append({
                "timestamp": datetime.now().isoformat(),
                "operation": "load_data",
                "dataset": dataset_name,
                "shape": df.shape,
                "data_type": data_type_param
            })

            # 数据质量分析
            quality_info = self._analyze_data_quality(df)

            return {
                "success": True,
                "dataset_id": dataset_name,
                "message": f"数据加载成功: {dataset_name}",
                "data_shape": df.shape,
                "columns": list(df.columns),
                "sample_data": df.head(3).to_dict('records'),
                "data_quality": quality_info,
                "data_types": {col: str(dtype) for col, dtype in df.dtypes.items()}
            }

        except Exception as e:
            logger.error(f"数据加载失败: {str(e)}")
            return {"error": f"数据加载失败: {str(e)}"}
    
    def _analyze_data_quality(self, df: pd.DataFrame) -> Dict[str, Any]:
        """分析数据质量"""
        quality_info = {
            "total_rows": len(df),
            "total_columns": len(df.columns),
            "missing_values": df.isnull().sum().to_dict(),
            "duplicate_rows": df.duplicated().sum(),
            "memory_usage": df.memory_usage(deep=True).sum(),
            "data_types": df.dtypes.value_counts().to_dict()
        }
        
        # 检测数值列
        numeric_columns = df.select_dtypes(include=[np.number]).columns.tolist()
        quality_info["numeric_columns"] = numeric_columns
        
        # 检测分类列
        categorical_columns = df.select_dtypes(include=['object', 'category']).columns.tolist()
        quality_info["categorical_columns"] = categorical_columns
        
        return quality_info
    
    def _load_sklearn_dataset(self, dataset_name: str) -> pd.DataFrame:
        """从sklearn加载数据集"""
        from sklearn.datasets import load_iris, load_wine, load_breast_cancer, load_diabetes, fetch_california_housing
        
        if dataset_name == "iris":
            data = load_iris()
        elif dataset_name == "wine":
            data = load_wine()
        elif dataset_name == "breast_cancer":
            data = load_breast_cancer()
        elif dataset_name == "diabetes":
            data = load_diabetes()
        elif dataset_name == "california_housing":
            data = fetch_california_housing()
        else:
            raise ValueError(f"不支持的sklearn数据集: {dataset_name}")
        
        # 构建DataFrame
        df = pd.DataFrame(data.data, columns=data.feature_names)
        if hasattr(data, 'target'):
            target_name = 'target'
            if hasattr(data, 'target_names') and dataset_name != 'california_housing':
                df[target_name] = [data.target_names[i] for i in data.target]
            else:
                df[target_name] = data.target
        
        return df
    
    def _load_sqlite_table(self, table_name: str) -> pd.DataFrame:
        """从SQLite数据库加载表"""
        db_path = SQLITE_CONFIG.get("default_path", "data/analysis.db")
        
        if not os.path.exists(db_path):
            raise FileNotFoundError(f"数据库文件不存在: {db_path}")
        
        conn = sqlite3.connect(db_path)
        try:
            df = pd.read_sql_query(f"SELECT * FROM {table_name}", conn)
        finally:
            conn.close()
        
        return df
    
    async def execute_pipeline_async(self, blocks_config: List[Dict], dataset_id: str = None) -> Dict[str, Any]:
        """异步执行积木流水线"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self.executor, 
            self.execute_pipeline, 
            blocks_config, 
            dataset_id
        )
    
    def execute_pipeline(self, blocks_config: List[Dict], dataset_id: str = None) -> Dict[str, Any]:
        """执行积木流水线 - 增强版"""
        try:
            # 获取当前数据集
            if not dataset_id:
                dataset_id = self.current_dataset_id

            if dataset_id not in self.datasets:
                return {"error": f"数据集不存在: {dataset_id}"}

            df = self.datasets[dataset_id]["data"].copy()
            execution_results = []
            execution_log = []
            processing_stats = {
                "start_time": time.time(),
                "blocks_count": len(blocks_config),
                "cache_hits": 0,
                "errors": []
            }

            for i, block in enumerate(blocks_config):
                block_type = block.get("type")
                params = block.get("params", {})
                block_name = block.get("name", f"block_{i + 1}")

                execution_log.append(f"执行积木 {i + 1}: {block_type} - {block_name}")

                # 检查缓存
                cache_key = f"{dataset_id}_{block_type}_{hash(str(params))}"
                if cache_key in self.processing_cache:
                    result = self.processing_cache[cache_key]
                    processing_stats["cache_hits"] += 1
                    logger.debug(f"缓存命中: {block_name}")
                else:
                    # 执行单个积木
                    result = self._execute_single_block(df, block_type, params, block_name)
                    
                    # 缓存结果
                    if "error" not in result:
                        self.processing_cache[cache_key] = result

                if "error" in result:
                    processing_stats["errors"].append({
                        "block": block_name,
                        "error": result["error"]
                    })
                    return {
                        "error": f"积木执行失败: {result['error']}",
                        "failed_block": block_name,
                        "execution_log": execution_log,
                        "processing_stats": processing_stats
                    }

                # 更新数据框
                if "data" in result:
                    df = result["data"]

                # 记录结果
                execution_results.append({
                    "block_name": block_name,
                    "block_type": block_type,
                    "result": result.get("summary", "执行成功"),
                    "data_shape_after": df.shape,
                    "details": result.get("details", {}),
                    "execution_time": result.get("execution_time", 0)
                })

            # 更新数据集
            self.datasets[dataset_id] = {
                "data": df, 
                "timestamp": time.time(),
                "last_modified": datetime.now().isoformat()
            }

            # 记录历史
            self.analysis_history.append({
                "timestamp": datetime.now().isoformat(),
                "operation": "execute_pipeline",
                "dataset": dataset_id,
                "blocks_executed": len(blocks_config),
                "final_shape": df.shape,
                "processing_time": time.time() - processing_stats["start_time"]
            })

            processing_stats["end_time"] = time.time()
            processing_stats["total_time"] = processing_stats["end_time"] - processing_stats["start_time"]

            return {
                "success": True,
                "execution_results": execution_results,
                "final_data_shape": df.shape,
                "sample_data": df.head(5).to_dict('records'),
                "columns_info": {
                    "names": list(df.columns),
                    "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()}
                },
                "execution_log": execution_log,
                "processing_stats": processing_stats,
                "data_summary": self._generate_data_summary(df)
            }

        except Exception as e:
            logger.error(f"积木流水线执行失败: {str(e)}")
            return {"error": f"积木流水线执行失败: {str(e)}", "traceback": traceback.format_exc()}
    
    def _generate_data_summary(self, df: pd.DataFrame) -> Dict[str, Any]:
        """生成数据摘要"""
        summary = {
            "shape": df.shape,
            "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
            "numeric_summary": {},
            "categorical_summary": {}
        }
        
        # 数值列摘要
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            summary["numeric_summary"] = {
                "count": len(numeric_cols),
                "columns": list(numeric_cols),
                "statistics": df[numeric_cols].describe().to_dict()
            }
        
        # 分类列摘要
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns
        if len(categorical_cols) > 0:
            summary["categorical_summary"] = {
                "count": len(categorical_cols),
                "columns": list(categorical_cols),
                "unique_counts": {col: df[col].nunique() for col in categorical_cols}
            }
        
        return summary
    
    def _execute_single_block(self, df: pd.DataFrame, block_type: str, params: Dict, block_name: str) -> Dict:
        """执行单个积木 - 增强版"""
        start_time = time.time()
        try:
            if block_type == "clean":
                result = self._clean_block(df, params, block_name)
            elif block_type == "filter":
                result = self._filter_block(df, params, block_name)
            elif block_type == "transform":
                result = self._transform_block(df, params, block_name)
            elif block_type == "analyze":
                result = self._analyze_block(df, params, block_name)
            elif block_type == "groupby":
                result = self._groupby_block(df, params, block_name)
            elif block_type == "join":
                result = self._join_block(df, params, block_name)
            elif block_type == "visualize":
                result = self._visualize_block(df, params, block_name)
            elif block_type == "smart_recommend":
                result = self._smart_recommend_block(df, params, block_name)
            else:
                return {"error": f"不支持的积木类型: {block_type}"}
            
            result["execution_time"] = time.time() - start_time
            return result
            
        except Exception as e:
            logger.error(f"积木执行错误: {str(e)}")
            return {"error": f"积木执行错误: {str(e)}", "traceback": traceback.format_exc()}
    
    def _smart_recommend_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """智能推荐积木 - 新增功能"""
        recommendations = []
        
        # 基于数据特征推荐分析
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        
        if len(numeric_cols) >= 2:
            recommendations.append({
                "type": "correlation_analysis",
                "description": "检测数值变量间的相关性",
                "suggested_blocks": [
                    {"type": "analyze", "params": {"analysis_type": "correlation"}},
                    {"type": "visualize", "params": {"chart_type": "heatmap"}}
                ]
            })
        
        if len(categorical_cols) >= 1 and len(numeric_cols) >= 1:
            recommendations.append({
                "type": "group_analysis", 
                "description": "按类别分组分析数值变量",
                "suggested_blocks": [
                    {"type": "groupby", "params": {"group_columns": [categorical_cols[0]], "agg_functions": {numeric_cols[0]: ["mean", "count"]}}},
                    {"type": "visualize", "params": {"chart_type": "bar"}}
                ]
            })
        
        if len(numeric_cols) >= 1:
            recommendations.append({
                "type": "distribution_analysis",
                "description": "分析数值变量分布",
                "suggested_blocks": [
                    {"type": "analyze", "params": {"analysis_type": "basic"}},
                    {"type": "visualize", "params": {"chart_type": "histogram"}}
                ]
            })
        
        return {
            "data": df,
            "summary": f"智能推荐完成，发现 {len(recommendations)} 个分析建议",
            "details": {
                "recommendations": recommendations,
                "data_characteristics": {
                    "numeric_columns": numeric_cols,
                    "categorical_columns": categorical_cols,
                    "total_columns": len(df.columns)
                }
            }
        }
    
    def _clean_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """数据清洗积木 - 增强版"""
        original_shape = df.shape
        operations = params.get("operations", [])
        cleaning_stats = {
            "operations_performed": [],
            "rows_removed": 0,
            "columns_removed": 0,
            "values_filled": 0
        }

        for op in operations:
            method = op.get("method")
            if method == "fillna":
                columns = op.get("columns", df.columns)
                value = op.get("value", 0)
                before_na = df[columns].isnull().sum().sum()
                df[columns] = df[columns].fillna(value)
                after_na = df[columns].isnull().sum().sum()
                values_filled = before_na - after_na
                cleaning_stats["values_filled"] += values_filled
                cleaning_stats["operations_performed"].append(f"填充缺失值: {values_filled} 个")

            elif method == "drop_duplicates":
                before_len = len(df)
                df = df.drop_duplicates()
                rows_removed = before_len - len(df)
                cleaning_stats["rows_removed"] += rows_removed
                cleaning_stats["operations_performed"].append(f"删除重复行: {rows_removed} 行")

            elif method == "drop_columns":
                columns = op.get("columns", [])
                before_cols = len(df.columns)
                df = df.drop(columns=columns)
                cols_removed = before_cols - len(df.columns)
                cleaning_stats["columns_removed"] += cols_removed
                cleaning_stats["operations_performed"].append(f"删除列: {cols_removed} 列")

            elif method == "rename_columns":
                rename_map = op.get("rename_map", {})
                df = df.rename(columns=rename_map)
                cleaning_stats["operations_performed"].append(f"重命名列: {len(rename_map)} 列")

            elif method == "correct_types":
                type_map = op.get("type_map", {})
                for col, dtype in type_map.items():
                    if col in df.columns:
                        try:
                            if dtype == "datetime":
                                df[col] = pd.to_datetime(df[col])
                            else:
                                df[col] = df[col].astype(dtype)
                            cleaning_stats["operations_performed"].append(f"转换列类型: {col} -> {dtype}")
                        except:
                            pass

        return {
            "data": df,
            "summary": f"数据清洗完成: {original_shape} -> {df.shape}",
            "details": cleaning_stats
        }
    
    def _filter_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """数据过滤积木 - 增强版"""
        original_shape = df.shape
        filter_conditions = params.get("conditions", [])
        
        if filter_conditions:
            for condition in filter_conditions:
                column = condition.get("column")
                operator = condition.get("operator")
                value = condition.get("value")
                
                if column in df.columns:
                    if operator == "==":
                        df = df[df[column] == value]
                    elif operator == "!=":
                        df = df[df[column] != value]
                    elif operator == ">":
                        df = df[df[column] > value]
                    elif operator == "<":
                        df = df[df[column] < value]
                    elif operator == ">=":
                        df = df[df[column] >= value]
                    elif operator == "<=":
                        df = df[df[column] <= value]
                    elif operator == "in":
                        df = df[df[column].isin(value)]
                    elif operator == "contains":
                        df = df[df[column].str.contains(str(value), na=False)]

        return {
            "data": df,
            "summary": f"数据过滤完成: {original_shape} -> {df.shape}",
            "details": {
                "rows_kept": df.shape[0],
                "rows_filtered_out": original_shape[0] - df.shape[0],
                "filter_conditions": filter_conditions
            }
        }
    
    def _transform_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """数据转换积木 - 增强版"""
        action = params.get("action", "")
        transform_stats = {"action_performed": action}

        if action == "select":
            columns = params.get("columns", [])
            df = df[columns]
            transform_stats["selected_columns"] = columns

        elif action == "sort":
            by = params.get("by", [])
            ascending = params.get("ascending", True)
            df = df.sort_values(by=by, ascending=ascending)
            transform_stats["sort_columns"] = by

        elif action == "create_column":
            column_name = params.get("column_name")
            expression = params.get("expression", "")
            if expression and column_name:
                try:
                    df[column_name] = eval(expression, {"df": df, "np": np, "pd": pd})
                    transform_stats["new_column"] = column_name
                except Exception as e:
                    logger.warning(f"创建列失败: {str(e)}")

        elif action == "pivot":
            index = params.get("index")
            columns = params.get("columns")
            values = params.get("values")
            aggfunc = params.get("aggfunc", "mean")
            if all([index, columns, values]):
                df = df.pivot_table(index=index, columns=columns, values=values, aggfunc=aggfunc)
                transform_stats["pivot_info"] = {"index": index, "columns": columns, "values": values}

        elif action == "melt":
            id_vars = params.get("id_vars", [])
            value_vars = params.get("value_vars", [])
            var_name = params.get("var_name", "variable")
            value_name = params.get("value_name", "value")
            df = df.melt(id_vars=id_vars, value_vars=value_vars, var_name=var_name, value_name=value_name)
            transform_stats["melt_info"] = {"id_vars": id_vars, "value_vars": value_vars}

        return {
            "data": df,
            "summary": f"数据转换完成: {df.shape}",
            "details": transform_stats
        }
    
    def _analyze_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """数据分析积木 - 增强版"""
        analysis_type = params.get("analysis_type", "basic")
        results = {}
        
        if analysis_type == "basic":
            results["description"] = df.describe().to_dict()
            results["info"] = {
                "shape": df.shape,
                "columns": list(df.columns),
                "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
                "null_counts": df.isnull().sum().to_dict(),
                "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2)
            }
            
        elif analysis_type == "correlation":
            numeric_df = df.select_dtypes(include=[np.number])
            if not numeric_df.empty:
                corr_matrix = numeric_df.corr()
                results["correlation_matrix"] = corr_matrix.to_dict()
                results["strong_correlations"] = self._find_strong_correlations(corr_matrix)
                
        elif analysis_type == "value_counts":
            column = params.get("column")
            if column and column in df.columns:
                results["value_counts"] = df[column].value_counts().to_dict()
                results["unique_values"] = df[column].nunique()
                
        elif analysis_type == "outliers":
            numeric_df = df.select_dtypes(include=[np.number])
            if not numeric_df.empty:
                results["outliers"] = self._detect_outliers(numeric_df)
                
        elif analysis_type == "distribution":
            numeric_df = df.select_dtypes(include=[np.number])
            if not numeric_df.empty:
                results["distributions"] = {}
                for col in numeric_df.columns:
                    results["distributions"][col] = {
                        "skewness": float(numeric_df[col].skew()),
                        "kurtosis": float(numeric_df[col].kurtosis()),
                        "normality_pvalue": float(self._normality_test(numeric_df[col]))
                    }

        return {
            "data": df,
            "summary": f"数据分析完成: {analysis_type}",
            "details": results
        }
    
    def _find_strong_correlations(self, corr_matrix: pd.DataFrame, threshold: float = 0.7) -> List[Dict]:
        """查找强相关性"""
        strong_corr = []
        for i in range(len(corr_matrix.columns)):
            for j in range(i+1, len(corr_matrix.columns)):
                corr_val = corr_matrix.iloc[i, j]
                if abs(corr_val) >= threshold:
                    strong_corr.append({
                        "var1": corr_matrix.columns[i],
                        "var2": corr_matrix.columns[j],
                        "correlation": float(corr_val)
                    })
        return strong_corr
    
    def _detect_outliers(self, df: pd.DataFrame, method: str = "iqr") -> Dict[str, Any]:
        """检测异常值"""
        outliers_info = {}
        
        for col in df.columns:
            if method == "iqr":
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)]
                outliers_info[col] = {
                    "method": "iqr",
                    "outlier_count": len(outliers),
                    "outlier_percentage": round(len(outliers) / len(df) * 100, 2),
                    "bounds": {"lower": float(lower_bound), "upper": float(upper_bound)}
                }
            elif method == "zscore":
                z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
                outliers = df[z_scores > 3]
                outliers_info[col] = {
                    "method": "zscore",
                    "outlier_count": len(outliers),
                    "outlier_percentage": round(len(outliers) / len(df) * 100, 2)
                }
        
        return outliers_info
    
    def _normality_test(self, series: pd.Series) -> float:
        """正态性检验（简化版）"""
        try:
            from scipy import stats
            _, p_value = stats.normaltest(series.dropna())
            return p_value
        except:
            return 0.0
    
    def _groupby_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """分组聚合积木 - 增强版"""
        group_columns = params.get("group_columns", [])
        agg_functions = params.get("agg_functions", {})
        sort_results = params.get("sort_results", True)
        limit = params.get("limit", None)

        if group_columns and agg_functions:
            # 确保分组列存在
            valid_columns = [col for col in group_columns if col in df.columns]
            if valid_columns:
                grouped = df.groupby(valid_columns)
                result_df = grouped.agg(agg_functions).reset_index()
                
                # 排序
                if sort_results and len(result_df) > 0:
                    sort_by = params.get("sort_by", valid_columns[0])
                    ascending = params.get("ascending", False)
                    result_df = result_df.sort_values(sort_by, ascending=ascending)
                
                # 限制结果数量
                if limit and limit > 0:
                    result_df = result_df.head(limit)
                
                return {
                    "data": result_df,
                    "summary": f"分组聚合完成: {len(result_df)} 组",
                    "details": {
                        "group_columns": valid_columns,
                        "agg_functions": agg_functions,
                        "result_shape": result_df.shape,
                        "groups_count": len(result_df)
                    }
                }
        
        return {
            "data": df,
            "summary": "分组聚合跳过：参数不完整",
            "details": {"group_columns": group_columns, "agg_functions": agg_functions}
        }
    
    def _join_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """数据关联积木 - 增强版"""
        right_dataset_id = params.get("right_dataset_id")
        join_type = params.get("join_type", "inner")
        left_on = params.get("left_on")
        right_on = params.get("right_on")
        
        if not right_dataset_id or right_dataset_id not in self.datasets:
            return {"error": f"右侧数据集不存在: {right_dataset_id}"}
        
        right_df = self.datasets[right_dataset_id]["data"]
        
        # 确定连接键
        if not left_on:
            left_on = df.columns[0]  # 默认使用第一列
        if not right_on:
            right_on = right_df.columns[0]  # 默认使用第一列
        
        try:
            if join_type == "inner":
                result_df = df.merge(right_df, left_on=left_on, right_on=right_on, how="inner")
            elif join_type == "left":
                result_df = df.merge(right_df, left_on=left_on, right_on=right_on, how="left")
            elif join_type == "right":
                result_df = df.merge(right_df, left_on=left_on, right_on=right_on, how="right")
            elif join_type == "outer":
                result_df = df.merge(right_df, left_on=left_on, right_on=right_on, how="outer")
            else:
                return {"error": f"不支持的连接类型: {join_type}"}
            
            return {
                "data": result_df,
                "summary": f"数据关联完成: {df.shape} + {right_df.shape} -> {result_df.shape}",
                "details": {
                    "join_type": join_type,
                    "left_on": left_on,
                    "right_on": right_on,
                    "left_shape": df.shape,
                    "right_shape": right_df.shape,
                    "result_shape": result_df.shape
                }
            }
        except Exception as e:
            return {"error": f"数据关联失败: {str(e)}"}
    
    def _visualize_block(self, df: pd.DataFrame, params: Dict, block_name: str) -> Dict:
        """可视化积木 - 增强版"""
        chart_type = params.get("chart_type", "bar")
        x_column = params.get("x_column")
        y_column = params.get("y_column")
        color_column = params.get("color_column")
        title = params.get("title", f"{chart_type} Chart")
        save_path = params.get("save_path")
        
        try:
            fig = None
            
            if chart_type == "bar":
                if x_column and y_column:
                    fig = px.bar(df, x=x_column, y=y_column, color=color_column, title=title)
                else:
                    fig = px.bar(df, title=title)
                    
            elif chart_type == "line":
                if x_column and y_column:
                    fig = px.line(df, x=x_column, y=y_column, color=color_column, title=title)
                else:
                    fig = px.line(df, title=title)
                    
            elif chart_type == "scatter":
                if x_column and y_column:
                    fig = px.scatter(df, x=x_column, y=y_column, color=color_column, title=title)
                else:
                    fig = px.scatter(df, title=title)
                    
            elif chart_type == "pie":
                if x_column:
                    fig = px.pie(df, names=x_column, values=y_column, title=title)
                    
            elif chart_type == "histogram":
                if x_column:
                    fig = px.histogram(df, x=x_column, color=color_column, title=title)
                    
            elif chart_type == "box":
                if x_column and y_column:
                    fig = px.box(df, x=x_column, y=y_column, color=color_column, title=title)
                elif x_column:
                    fig = px.box(df, x=x_column, title=title)
                    
            elif chart_type == "heatmap":
                numeric_df = df.select_dtypes(include=[np.number])
                if not numeric_df.empty:
                    fig = px.imshow(numeric_df.corr(), title="Correlation Heatmap")
            
            if fig is None:
                return {"error": f"不支持的图表类型或参数不完整: {chart_type}"}
            
            # 保存图表
            if save_path:
                fig.write_html(save_path)
            
            # 转换为base64用于显示
            img_base64 = fig.to_image(format="png", engine="kaleido") if hasattr(fig, 'to_image') else None
            
            return {
                "data": df,
                "summary": f"可视化完成: {chart_type}",
                "details": {
                    "chart_type": chart_type,
                    "x_column": x_column,
                    "y_column": y_column,
                    "color_column": color_column,
                    "title": title,
                    "save_path": save_path,
                    "figure_html": fig.to_html() if fig else None
                }
            }
            
        except Exception as e:
            logger.error(f"可视化失败: {str(e)}")
            return {"error": f"可视化失败: {str(e)}"}
    
    def get_dataset_info(self, dataset_id: str = None) -> Dict[str, Any]:
        """获取数据集信息"""
        if not dataset_id:
            dataset_id = self.current_dataset_id
            
        if dataset_id not in self.datasets:
            return {"error": f"数据集不存在: {dataset_id}"}
        
        dataset_info = self.datasets[dataset_id]
        df = dataset_info["data"]
        
        return {
            "dataset_id": dataset_id,
            "shape": df.shape,
            "columns": list(df.columns),
            "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
            "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
            "timestamp": dataset_info["timestamp"],
            "data_type": dataset_info.get("data_type", "unknown"),
            "sample_data": df.head(3).to_dict('records')
        }
    
    def cleanup_old_datasets(self):
        """清理过期数据集"""
        current_time = time.time()
        timeout = DATASET_CONFIG["default_timeout"]
        
        expired_datasets = []
        for dataset_id, info in self.datasets.items():
            if current_time - info["timestamp"] > timeout:
                expired_datasets.append(dataset_id)
        
        for dataset_id in expired_datasets:
            del self.datasets[dataset_id]
            logger.info(f"清理过期数据集: {dataset_id}")
        
        # 清理缓存
        if len(self.processing_cache) > 1000:
            self.processing_cache.clear()
            logger.info("清理处理缓存")
        
        return len(expired_datasets)
    
    def _start_cleanup_service(self):
        """启动异步清理服务"""
        def cleanup_worker():
            while True:
                try:
                    time.sleep(DATASET_CONFIG["cleanup_interval"])
                    self.cleanup_old_datasets()
                except Exception as e:
                    logger.error(f"清理服务错误: {str(e)}")
        
        thread = threading.Thread(target=cleanup_worker, daemon=True)
        thread.start()
        logger.info("数据集清理服务已启动")


# 创建全局引擎实例
engine = EnhancedPandasBlocksEngine()