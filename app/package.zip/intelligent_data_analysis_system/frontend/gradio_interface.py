#!/usr/bin/env python3
"""
智能数据问答分析系统 - Gradio前端界面
基于Python的交互式Web界面
"""

import gradio as gr
import asyncio
import json
import time
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from typing import Dict, List, Any, Optional
import io
import base64
from datetime import datetime
import os
from loguru import logger

# 设置日志
logger.add("logs/frontend.log", rotation="10 MB", retention="30 days")

# 导入后端服务
import sys
sys.path.append('.')

from api.main import app
from core.agent_coordinator import coordinator
from core.enhanced_fastmcp import engine
from core.config import FRONTEND_CONFIG


class GradioInterface:
    """Gradio界面管理器"""
    
    def __init__(self):
        self.current_session_id = None
        self.chat_history = []
        self.datasets_cache = {}
        self.processing_status = {}
        
        logger.info("Gradio界面管理器初始化完成")
    
    def create_interface(self):
        """创建Gradio界面"""
        
        # 自定义CSS样式
        css = """
        .gradio-container {
            max-width: 1200px !important;
            margin: auto !important;
        }
        .chat-message {
            padding: 10px;
            margin: 5px 0;
            border-radius: 10px;
        }
        .user-message {
            background-color: #e3f2fd;
            margin-left: 20%;
        }
        .bot-message {
            background-color: #f5f5f5;
            margin-right: 20%;
        }
        .dataset-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            margin: 5px 0;
        }
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 5px;
        }
        .status-success { background-color: #4caf50; }
        .status-error { background-color: #f44336; }
        .status-processing { background-color: #ff9800; }
        """
        
        with gr.Blocks(css=css, title="智能数据问答分析系统") as interface:
            
            # 标题
            gr.HTML("""
            <div style="text-align: center; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 10px; margin-bottom: 20px;">
                <h1>🤖 智能数据问答分析系统</h1>
                <p>基于多智能体的智能数据分析平台</p>
            </div>
            """)
            
            with gr.Tab("💬 智能问答"):
                self._create_chat_tab()
            
            with gr.Tab("📊 数据管理"):
                self._create_data_management_tab()
            
            with gr.Tab("📈 可视化"):
                self._create_visualization_tab()
            
            with gr.Tab("⚙️ 系统状态"):
                self._create_status_tab()
        
        return interface
    
    def _create_chat_tab(self):
        """创建聊天标签页"""
        
        with gr.Row():
            with gr.Column(scale=3):
                # 聊天历史
                chatbot = gr.Chatbot(
                    label="对话历史",
                    height=400,
                    elem_id="chatbot"
                )
                
                # 输入区域
                with gr.Row():
                    query_input = gr.Textbox(
                        label="输入您的查询",
                        placeholder="例如：帮我分析一下销售数据，看看各地区的销售趋势...",
                        lines=3,
                        elem_id="query_input"
                    )
                
                with gr.Row():
                    dataset_dropdown = gr.Dropdown(
                        label="选择数据集（可选）",
                        choices=self._get_dataset_choices(),
                        value=None,
                        elem_id="dataset_dropdown"
                    )
                
                with gr.Row():
                    submit_btn = gr.Button("🚀 提交查询", variant="primary")
                    clear_btn = gr.Button("🗑️ 清空对话")
            
            with gr.Column(scale=2):
                # 结果展示区域
                gr.HTML("<h3>📋 查询结果</h3>")
                
                result_output = gr.JSON(
                    label="处理结果",
                    height=300,
                    elem_id="result_output"
                )
                
                # 状态显示
                status_display = gr.HTML(
                    self._create_status_html("ready"),
                    elem_id="status_display"
                )
                
                # 建议操作
                gr.HTML("<h4>💡 建议操作</h4>")
                suggestions_output = gr.JSON(
                    label="智能建议",
                    height=150,
                    elem_id="suggestions_output"
                )
        
        # 事件绑定
        submit_btn.click(
            fn=self._process_query,
            inputs=[query_input, dataset_dropdown],
            outputs=[chatbot, result_output, status_display, suggestions_output, dataset_dropdown]
        )
        
        clear_btn.click(
            fn=self._clear_chat,
            outputs=[chatbot, result_output, status_display, suggestions_output]
        )
        
        # 刷新数据集列表
        dataset_dropdown.change(
            fn=self._get_dataset_choices,
            outputs=[dataset_dropdown]
        )
    
    def _create_data_management_tab(self):
        """创建数据管理标签页"""
        
        with gr.Row():
            with gr.Column():
                gr.HTML("<h3>📁 上传数据集</h3>")
                
                with gr.Row():
                    file_upload = gr.File(
                        label="选择文件",
                        file_types=[".csv", ".json", ".xlsx", ".xls", ".db"],
                        height=100
                    )
                
                with gr.Row():
                    dataset_name = gr.Textbox(
                        label="数据集名称（可选）",
                        placeholder="如果不填写，将自动生成"
                    )
                    
                    data_type = gr.Dropdown(
                        label="数据类型",
                        choices=["auto", "csv", "json", "excel", "sqlite"],
                        value="auto"
                    )
                
                upload_btn = gr.Button("📤 上传数据集", variant="primary")
                
                upload_status = gr.HTML(elem_id="upload_status")
            
            with gr.Column():
                gr.HTML("<h3>🗂️ 内置数据集</h3>")
                
                sklearn_datasets = gr.Dropdown(
                    label="选择sklearn数据集",
                    choices=["iris", "wine", "breast_cancer", "diabetes", "california_housing"],
                    value="iris"
                )
                
                custom_name = gr.Textbox(
                    label="自定义名称（可选）",
                    placeholder="例如：my_iris_data"
                )
                
                load_sklearn_btn = gr.Button("📥 加载数据集")
                
                sklearn_status = gr.HTML(elem_id="sklearn_status")
        
        # 数据集列表
        gr.HTML("<h3>📋 已加载的数据集</h3>")
        
        with gr.Row():
            refresh_btn = gr.Button("🔄 刷新列表")
            cleanup_btn = gr.Button("🧹 清理过期数据")
        
        datasets_list = gr.JSON(
            label="数据集列表",
            height=300,
            elem_id="datasets_list"
        )
        
        # 事件绑定
        upload_btn.click(
            fn=self._upload_dataset,
            inputs=[file_upload, dataset_name, data_type],
            outputs=[upload_status, datasets_list]
        )
        
        load_sklearn_btn.click(
            fn=self._load_sklearn_dataset,
            inputs=[sklearn_datasets, custom_name],
            outputs=[sklearn_status, datasets_list]
        )
        
        refresh_btn.click(
            fn=self._refresh_datasets,
            outputs=[datasets_list]
        )
        
        cleanup_btn.click(
            fn=self._cleanup_data,
            outputs=[datasets_list]
        )
    
    def _create_visualization_tab(self):
        """创建可视化标签页"""
        
        with gr.Row():
            with gr.Column():
                gr.HTML("<h3>📊 快速可视化</h3>")
                
                viz_dataset = gr.Dropdown(
                    label="选择数据集",
                    choices=self._get_dataset_choices(),
                    elem_id="viz_dataset"
                )
                
                chart_type = gr.Dropdown(
                    label="图表类型",
                    choices=["bar", "line", "scatter", "pie", "histogram", "box", "heatmap"],
                    value="bar"
                )
                
                x_column = gr.Dropdown(
                    label="X轴列",
                    choices=[],
                    elem_id="x_column"
                )
                
                y_column = gr.Dropdown(
                    label="Y轴列",
                    choices=[],
                    elem_id="y_column"
                )
                
                color_column = gr.Dropdown(
                    label="颜色分组列（可选）",
                    choices=[],
                    elem_id="color_column"
                )
                
                create_viz_btn = gr.Button("🎨 创建图表", variant="primary")
            
            with gr.Column():
                gr.HTML("<h3>📈 图表结果</h3>")
                
                plot_output = gr.Plot(
                    label="生成的图表",
                    height=400
                )
                
                viz_info = gr.JSON(
                    label="图表信息",
                    height=150
                )
        
        # 事件绑定
        viz_dataset.change(
            fn=self._update_column_choices,
            inputs=[viz_dataset],
            outputs=[x_column, y_column, color_column]
        )
        
        create_viz_btn.click(
            fn=self._create_visualization,
            inputs=[viz_dataset, chart_type, x_column, y_column, color_column],
            outputs=[plot_output, viz_info]
        )
    
    def _create_status_tab(self):
        """创建系统状态标签页"""
        
        with gr.Row():
            with gr.Column():
                gr.HTML("<h3>📊 处理统计</h3>")
                
                stats_refresh_btn = gr.Button("🔄 刷新统计")
                
                stats_output = gr.JSON(
                    label="系统统计",
                    height=300
                )
            
            with gr.Column():
                gr.HTML("<h3>🖥️ 系统信息</h3>")
                
                system_info = gr.JSON(
                    label="系统信息",
                    height=200
                )
                
                health_status = gr.HTML(
                    label="健康状态",
                    elem_id="health_status"
                )
        
        # 事件绑定
        stats_refresh_btn.click(
            fn=self._get_system_stats,
            outputs=[stats_output, system_info, health_status]
        )
        
        # 初始化时加载统计信息
        interface.load(
            fn=self._get_system_stats,
            outputs=[stats_output, system_info, health_status]
        )
    
    def _get_dataset_choices(self) -> List[str]:
        """获取数据集选择列表"""
        try:
            datasets = list(engine.datasets.keys())
            return datasets
        except:
            return []
    
    async def _process_query(self, query: str, dataset_id: str = None):
        """处理用户查询"""
        try:
            if not query.strip():
                yield self.chat_history, {}, self._create_status_html("error", "请输入查询内容"), [], self._get_dataset_choices()
                return
            
            # 更新状态
            status_html = self._create_status_html("processing", "正在处理查询...")
            yield self.chat_history, {}, status_html, [], self._get_dataset_choices()
            
            # 添加用户消息到历史
            self.chat_history.append({"role": "user", "content": query})
            
            # 生成会话ID
            self.current_session_id = f"gradio_{int(time.time())}"
            
            # 调用协调器处理查询
            result = await coordinator.process_query(
                user_query=query,
                dataset_id=dataset_id,
                session_id=self.current_session_id
            )
            
            # 处理结果
            if result.get('success'):
                # 格式化回复
                bot_response = self._format_bot_response(result)
                self.chat_history.append({"role": "assistant", "content": bot_response})
                
                # 更新状态
                status_html = self._create_status_html("success", "查询处理完成")
                
                # 提取建议
                suggestions = result.get('next_actions', [])
                
                yield self.chat_history, result, status_html, suggestions, self._get_dataset_choices()
            else:
                # 处理失败
                error_msg = result.get('error', '未知错误')
                self.chat_history.append({"role": "assistant", "content": f"❌ 处理失败: {error_msg}"})
                
                status_html = self._create_status_html("error", f"处理失败: {error_msg}")
                suggestions = result.get('suggestions', [])
                
                yield self.chat_history, result, status_html, suggestions, self._get_dataset_choices()
                
        except Exception as e:
            logger.error(f"处理查询失败: {str(e)}")
            error_msg = f"系统错误: {str(e)}"
            self.chat_history.append({"role": "assistant", "content": f"❌ {error_msg}"})
            
            status_html = self._create_status_html("error", error_msg)
            
            yield self.chat_history, {"error": error_msg}, status_html, [], self._get_dataset_choices()
    
    def _format_bot_response(self, result: Dict[str, Any]) -> str:
        """格式化机器人回复"""
        try:
            response_parts = []
            
            # 基本信息
            intent_info = result.get('intent_analysis', {})
            if intent_info:
                intent = intent_info.get('primary_intent', '查询')
                confidence = intent_info.get('confidence', 0)
                response_parts.append(f"🎯 检测到意图: {intent} (置信度: {confidence:.2f})")
            
            # 数据洞察
            data_insights = result.get('data_insights', [])
            if data_insights:
                response_parts.append("\n📊 数据洞察:")
                for insight in data_insights[:3]:  # 只显示前3个
                    response_parts.append(f"• {insight}")
            
            # 工作流信息
            workflow_info = result.get('workflow_info', {})
            if workflow_info:
                steps = workflow_info.get('steps_executed', 0)
                exec_time = workflow_info.get('execution_time', 0)
                response_parts.append(f"\n⚙️ 执行了 {steps} 个步骤，耗时 {exec_time:.2f} 秒")
            
            # 成功结果摘要
            successful_results = result.get('results', {}).get('successful_results', {})
            if successful_results:
                response_parts.append("\n✅ 处理结果:")
                for step, step_result in successful_results.items():
                    if step == 'data_processing':
                        summary = step_result.get('task_summary', {})
                        if summary:
                            response_parts.append(f"• 数据处理: {summary.get('successful_blocks', 0)}/{summary.get('total_blocks', 0)} 个步骤成功")
                    elif step == 'visualization':
                        viz_summary = step_result.get('summary', {})
                        if viz_summary:
                            response_parts.append(f"• 可视化: 生成了 {viz_summary.get('total_charts', 0)} 个图表")
                    elif step == 'sql_query':
                        sql_info = step_result.get('query_explanation', {})
                        if sql_info:
                            response_parts.append(f"• SQL查询: {sql_info.get('query_purpose', '生成完成')}")
            
            return "\n".join(response_parts)
            
        except Exception as e:
            logger.error(f"格式化回复失败: {str(e)}")
            return "✅ 查询处理完成，请查看详细结果。"
    
    def _clear_chat(self):
        """清空聊天历史"""
        self.chat_history = []
        self.current_session_id = None
        status_html = self._create_status_html("ready", "已清空对话")
        return [], {}, status_html, [], self._get_dataset_choices()
    
    def _create_status_html(self, status: str, message: str) -> str:
        """创建状态HTML"""
        status_classes = {
            "ready": "status-success",
            "processing": "status-processing", 
            "success": "status-success",
            "error": "status-error"
        }
        
        status_class = status_classes.get(status, "status-error")
        
        return f"""
        <div class="status-indicator {status_class}"></div>
        <span>{message}</span>
        """
    
    def _upload_dataset(self, file, dataset_name: str, data_type: str):
        """上传数据集"""
        try:
            if not file:
                return self._create_status_html("error", "请选择文件"), {}
            
            # 读取文件内容
            content = file.read()
            
            # 生成数据集名称
            if not dataset_name:
                dataset_name = f"uploaded_{int(time.time())}_{file.name}"
            
            # 加载数据
            if data_type == "csv":
                result = engine.load_data(content.decode('utf-8'), "csv", dataset_name)
            elif data_type == "json":
                result = engine.load_data(content.decode('utf-8'), "json", dataset_name)
            elif data_type == "excel":
                result = engine.load_data(content, "excel", dataset_name)
            elif data_type == "sqlite":
                # 保存SQLite文件
                os.makedirs("data", exist_ok=True)
                file_path = f"data/{dataset_name}.db"
                with open(file_path, "wb") as f:
                    f.write(content)
                result = engine.load_data(dataset_name, "sqlite", dataset_name)
            else:
                result = engine.load_data(content, "auto", dataset_name)
            
            if "error" in result:
                status_html = self._create_status_html("error", result["error"])
            else:
                status_html = self._create_status_html("success", f"数据集 '{dataset_name}' 上传成功")
            
            # 刷新数据集列表
            datasets_list = self._get_datasets_list()
            
            return status_html, datasets_list
            
        except Exception as e:
            logger.error(f"上传数据集失败: {str(e)}")
            status_html = self._create_status_html("error", f"上传失败: {str(e)}")
            return status_html, {}
    
    def _load_sklearn_dataset(self, dataset_name: str, custom_name: str = None):
        """加载sklearn数据集"""
        try:
            result = engine.load_data(dataset_name, "sk-learn", custom_name)
            
            if "error" in result:
                status_html = self._create_status_html("error", result["error"])
            else:
                status_html = self._create_status_html("success", f"数据集 '{result['dataset_id']}' 加载成功")
            
            # 刷新数据集列表
            datasets_list = self._get_datasets_list()
            
            return status_html, datasets_list
            
        except Exception as e:
            logger.error(f"加载sklearn数据集失败: {str(e)}")
            status_html = self._create_status_html("error", f"加载失败: {str(e)}")
            return status_html, {}
    
    def _refresh_datasets(self):
        """刷新数据集列表"""
        return self._get_datasets_list()
    
    def _cleanup_data(self):
        """清理过期数据"""
        try:
            cleaned_datasets = engine.cleanup_old_datasets()
            cleaned_sessions = coordinator.cleanup_sessions()
            
            status_html = self._create_status_html("success", 
                f"清理完成: {cleaned_datasets} 个数据集, {cleaned_sessions} 个会话")
            
            return self._get_datasets_list()
            
        except Exception as e:
            logger.error(f"清理数据失败: {str(e)}")
            status_html = self._create_status_html("error", f"清理失败: {str(e)}")
            return self._get_datasets_list()
    
    def _get_datasets_list(self):
        """获取数据集列表"""
        try:
            datasets_info = []
            
            for dataset_id, dataset_info in engine.datasets.items():
                df = dataset_info["data"]
                datasets_info.append({
                    "dataset_id": dataset_id,
                    "name": dataset_id,
                    "data_type": dataset_info.get("data_type", "unknown"),
                    "shape": list(df.shape),
                    "columns": list(df.columns),
                    "upload_time": dataset_info.get("timestamp", 0),
                    "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2)
                })
            
            return {
                "datasets": datasets_info,
                "total_count": len(datasets_info)
            }
            
        except Exception as e:
            logger.error(f"获取数据集列表失败: {str(e)}")
            return {"error": str(e)}
    
    def _update_column_choices(self, dataset_id: str):
        """更新列选择"""
        if not dataset_id or dataset_id not in engine.datasets:
            return [], [], []
        
        try:
            df = engine.datasets[dataset_id]["data"]
            columns = list(df.columns)
            
            # 分离数值列和分类列
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
            
            all_cols = columns
            return all_cols, numeric_cols, categorical_cols
            
        except Exception as e:
            logger.error(f"更新列选择失败: {str(e)}")
            return [], [], []
    
    def _create_visualization(self, dataset_id: str, chart_type: str, x_col: str, y_col: str, color_col: str = None):
        """创建可视化"""
        try:
            if not dataset_id or dataset_id not in engine.datasets:
                return None, {"error": "请选择有效的数据集"}
            
            df = engine.datasets[datasets_id]["data"]
            
            # 创建图表
            if chart_type == "bar":
                if x_col and y_col:
                    fig = px.bar(df, x=x_col, y=y_col, color=color_col)
                else:
                    fig = px.bar(df)
                    
            elif chart_type == "line":
                if x_col and y_col:
                    fig = px.line(df, x=x_col, y=y_col, color=color_col)
                else:
                    fig = px.line(df)
                    
            elif chart_type == "scatter":
                if x_col and y_col:
                    fig = px.scatter(df, x=x_col, y=y_col, color=color_col)
                else:
                    fig = px.scatter(df)
                    
            elif chart_type == "pie":
                if x_col:
                    fig = px.pie(df, names=x_col, values=y_col)
                else:
                    return None, {"error": "饼图需要指定分类列和数值列"}
                    
            elif chart_type == "histogram":
                if x_col:
                    fig = px.histogram(df, x=x_col, color=color_col)
                else:
                    return None, {"error": "直方图需要指定数值列"}
                    
            elif chart_type == "box":
                if y_col:
                    if x_col:
                        fig = px.box(df, x=x_col, y=y_col, color=color_col)
                    else:
                        fig = px.box(df, y=y_col)
                else:
                    return None, {"error": "箱线图需要指定数值列"}
                    
            elif chart_type == "heatmap":
                numeric_df = df.select_dtypes(include=['number'])
                if not numeric_df.empty:
                    fig = px.imshow(numeric_df.corr())
                else:
                    return None, {"error": "热力图需要数值数据"}
            
            viz_info = {
                "chart_type": chart_type,
                "dataset_id": dataset_id,
                "x_column": x_col,
                "y_column": y_col,
                "color_column": color_col,
                "data_shape": list(df.shape)
            }
            
            return fig, viz_info
            
        except Exception as e:
            logger.error(f"创建可视化失败: {str(e)}")
            return None, {"error": f"创建图表失败: {str(e)}"}
    
    def _get_system_stats(self):
        """获取系统统计"""
        try:
            stats = coordinator.get_processing_stats()
            
            system_info = {
                "coordinator": "running",
                "mcp_engine": "running", 
                "agents": "running",
                "datasets_count": len(engine.datasets),
                "cache_size": len(coordinator.result_cache)
            }
            
            health_html = self._create_status_html("success", "系统运行正常")
            
            return stats, system_info, health_html
            
        except Exception as e:
            logger.error(f"获取系统统计失败: {str(e)}")
            return {}, {}, self._create_status_html("error", f"获取统计失败: {str(e)}")


def create_gradio_app():
    """创建Gradio应用"""
    # 创建日志目录
    os.makedirs("logs", exist_ok=True)
    
    # 创建界面管理器
    interface_manager = GradioInterface()
    
    # 创建界面
    interface = interface_manager.create_interface()
    
    return interface


if __name__ == "__main__":
    # 创建并启动Gradio应用
    interface = create_gradio_app()
    
    interface.launch(
        server_name=FRONTEND_CONFIG["server_name"],
        server_port=FRONTEND_CONFIG["server_port"],
        share=FRONTEND_CONFIG["share"],
        debug=FRONTEND_CONFIG["debug"],
        show_error=True
    )