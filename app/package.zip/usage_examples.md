# 智能数据问答分析系统 - 使用示例

## 快速开始

### 1. 系统启动

```bash
# 克隆项目并启动系统
git clone <repository-url>
cd intelligent-data-analysis-system

# 使用一键启动脚本
chmod +x start.sh
./start.sh
```

### 2. 访问系统

- **API文档**: http://localhost:8000/docs
- **前端界面**: http://localhost:3000
- **监控面板**: http://localhost:9090

## 使用示例

### 示例1：基础数据查询

**用户输入**：
```
显示销售数据的基本信息
```

**系统处理流程**：
1. **意图理解**：识别为数据查询意图
2. **任务分解**：生成数据加载 → 基础分析流水线
3. **数据处理**：加载数据并执行基础统计
4. **结果返回**：返回数据概览信息

**返回结果**：
```json
{
  "success": true,
  "result": {
    "data_shape": [1000, 15],
    "columns": ["订单ID", "客户名称", "销售金额", "销售日期", "地区"],
    "basic_stats": {
      "销售金额": {
        "mean": 1250.50,
        "std": 450.25,
        "min": 100.00,
        "max": 5000.00
      }
    },
    "data_quality": {
      "completeness": 98.5,
      "uniqueness": 95.2
    }
  }
}
```

### 示例2：智能数据分析

**用户输入**：
```
分析一下各地区的销售趋势，看看哪个地区增长最快
```

**系统处理流程**：
1. **意图理解**：识别为趋势分析 + 对比分析
2. **任务分解**：数据加载 → 时间过滤 → 分组聚合 → 趋势分析 → 可视化
3. **数据处理**：按地区分组计算销售趋势
4. **可视化生成**：生成趋势对比图表

**返回结果**：
```json
{
  "success": true,
  "result": {
    "trend_analysis": {
      "地区销售趋势": {
        "华东地区": {"增长率": 15.2%, "月均增长": 12500},
        "华南地区": {"增长率": 12.8%, "月均增长": 9800},
        "华北地区": {"增长率": 8.5%, "月均增长": 6500}
      },
      "增长最快地区": "华东地区"
    },
    "visualization": {
      "chart_type": "line",
      "title": "各地区销售趋势对比",
      "config": {
        "x_axis": "月份",
        "y_axis": "销售额",
        "series": "地区",
        "theme": "dark"
      }
    }
  }
}
```

### 示例3：复杂查询分析

**用户输入**：
```
帮我找出购买金额超过1000元且来自华东地区的客户，并分析他们的购买行为特征
```

**系统处理流程**：
1. **意图理解**：数据过滤 + 客户分析 + 行为分析
2. **任务分解**：数据加载 → 条件过滤 → 客户分组 → 行为分析 → 特征提取
3. **数据处理**：执行多条件过滤和深度分析
4. **结果整合**：生成客户画像和行为报告

**返回结果**：
```json
{
  "success": true,
  "result": {
    "filtered_data": {
      "total_customers": 156,
      "total_orders": 423,
      "total_amount": 678500
    },
    "customer_analysis": {
      "purchase_frequency": {
        "高频客户": 45,
        "中频客户": 78,
        "低频客户": 33
      },
      "average_order_value": 1604.25,
      "preferred_products": ["电子产品", "办公用品", "家居用品"]
    },
    "behavior_patterns": {
      "购买时段": {
        "上午": 25%,
        "下午": 45%,
        "晚上": 30%
      },
      "支付方式": {
        "支付宝": 60%,
        "微信支付": 30%,
        "银行卡": 10%
      }
    },
    "recommendations": [
      "针对高频客户推出会员计划",
      "在下午时段加强营销推广",
      "优化电子产品品类"
    ]
  }
}
```

### 示例4：自然语言SQL查询

**用户输入**：
```
查询去年销售额最高的前10个产品及其详细信息
```

**系统处理流程**：
1. **意图理解**：SQL查询意图
2. **任务分解**：SQL生成 → 查询执行 → 结果格式化
3. **SQL生成**：转换为SQL查询语句
4. **结果返回**：格式化查询结果

**返回结果**：
```json
{
  "success": true,
  "result": {
    "sql_query": "SELECT p.产品名称, SUM(o.销售金额) as 总销售额 FROM products p JOIN orders o ON p.产品ID = o.产品ID WHERE o.销售日期 >= '2023-01-01' GROUP BY p.产品ID, p.产品名称 ORDER BY 总销售额 DESC LIMIT 10",
    "execution_time": "0.045s",
    "data": [
      {
        "rank": 1,
        "product_name": "iPhone 15 Pro",
        "total_sales": 2450000,
        "order_count": 245,
        "average_price": 10000
      },
      {
        "rank": 2,
        "product_name": "MacBook Pro",
        "total_sales": 1890000,
        "order_count": 126,
        "average_price": 15000
      }
    ],
    "summary": {
      "total_products": 10,
      "total_sales": 8750000,
      "average_sales_per_product": 875000
    }
  }
}
```

## API使用示例

### Python客户端

```python
import requests
import json

class IntelligentDataAnalysisClient:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url
    
    def query(self, question: str) -> dict:
        """发送自然语言查询"""
        response = requests.post(
            f"{self.base_url}/api/v1/query",
            json={"question": question},
            headers={"Content-Type": "application/json"}
        )
        return response.json()
    
    def get_dataset_info(self, dataset_id: str = None) -> dict:
        """获取数据集信息"""
        params = {"dataset_id": dataset_id} if dataset_id else {}
        response = requests.get(f"{self.base_url}/api/v1/dataset/info", params=params)
        return response.json()
    
    def execute_pipeline(self, pipeline_config: list) -> dict:
        """执行数据处理流水线"""
        response = requests.post(
            f"{self.base_url}/api/v1/pipeline/execute",
            json={"pipeline": pipeline_config}
        )
        return response.json()

# 使用示例
client = IntelligentDataAnalysisClient()

# 示例1：自然语言查询
result = client.query("分析最近一个月的销售数据")
print(json.dumps(result, indent=2, ensure_ascii=False))

# 示例2：执行自定义流水线
pipeline = [
    {
        "type": "load_data",
        "params": {"data_source": "sales_2024.csv"}
    },
    {
        "type": "filter_data",
        "params": {"condition": "销售日期 >= '2024-01-01'"}
    },
    {
        "type": "group_analysis",
        "params": {
            "group_column": "地区",
            "agg_column": "销售金额",
            "agg_function": "sum"
        }
    }
]

result = client.execute_pipeline(pipeline)
print(json.dumps(result, indent=2, ensure_ascii=False))
```

### JavaScript客户端

```javascript
class IntelligentDataAnalysisClient {
    constructor(baseUrl = 'http://localhost:8000') {
        this.baseUrl = baseUrl;
    }
    
    async query(question) {
        const response = await fetch(`${this.baseUrl}/api/v1/query`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ question })
        });
        return await response.json();
    }
    
    async getDatasetInfo(datasetId = null) {
        const url = new URL(`${this.baseUrl}/api/v1/dataset/info`);
        if (datasetId) {
            url.searchParams.append('dataset_id', datasetId);
        }
        
        const response = await fetch(url);
        return await response.json();
    }
    
    async executePipeline(pipelineConfig) {
        const response = await fetch(`${this.baseUrl}/api/v1/pipeline/execute`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ pipeline: pipelineConfig })
        });
        return await response.json();
    }
}

// 使用示例
const client = new IntelligentDataAnalysisClient();

// 示例：分析销售趋势
async function analyzeSalesTrend() {
    try {
        const result = await client.query('分析各地区的销售趋势');
        console.log('分析结果:', result);
        
        // 如果有可视化结果，渲染图表
        if (result.visualization_result) {
            renderChart(result.visualization_result);
        }
    } catch (error) {
        console.error('查询失败:', error);
    }
}

function renderChart(vizResult) {
    // 使用Chart.js或D3.js渲染图表
    const ctx = document.getElementById('chart-canvas').getContext('2d');
    
    // 根据可视化配置创建图表
    new Chart(ctx, {
        type: vizResult.chart_configs[0].type,
        data: {
            // 根据返回数据设置图表数据
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: vizResult.chart_configs[0].title
                }
            }
        }
    });
}
```

## 前端集成示例

### React组件

```jsx
import React, { useState } from 'react';
import { IntelligentDataAnalysisClient } from './client';

const DataAnalysisInterface = () => {
    const [query, setQuery] = useState('');
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const client = new IntelligentDataAnalysisClient();

    const handleQuery = async () => {
        if (!query.trim()) return;
        
        setLoading(true);
        try {
            const response = await client.query(query);
            setResult(response);
        } catch (error) {
            console.error('查询失败:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderResult = () => {
        if (!result) return null;

        return (
            <div className="result-container">
                {result.success ? (
                    <div className="success-result">
                        <h3>分析结果</h3>
                        <div className="data-summary">
                            <p>数据形状: {result.result?.data_shape}</p>
                            <p>列名: {result.result?.columns?.join(', ')}</p>
                        </div>
                        
                        {result.visualization_result && (
                            <div className="visualization">
                                <h4>可视化图表</h4>
                                <ChartRenderer config={result.visualization_result} />
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="error-result">
                        <h3>查询失败</h3>
                        <p>{result.error}</p>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="data-analysis-interface">
            <div className="query-input-section">
                <textarea
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="请输入您的数据分析问题..."
                    className="query-input"
                />
                <button 
                    onClick={handleQuery}
                    disabled={loading}
                    className="query-button"
                >
                    {loading ? '分析中...' : '开始分析'}
                </button>
            </div>
            
            {renderResult()}
        </div>
    );
};

export default DataAnalysisInterface;
```

## 高级功能示例

### 1. 自定义数据源

```python
# 添加新的数据源
custom_source = {
    "type": "api",
    "name": "weather_api",
    "config": {
        "url": "https://api.weather.com/v1",
        "api_key": "your-api-key",
        "endpoints": {
            "current": "/current",
            "forecast": "/forecast"
        }
    }
}

# 使用自定义数据源
result = client.query("获取今天北京的天气数据并分析趋势")
```

### 2. 批量分析

```python
# 批量处理多个查询
queries = [
    "分析销售数据的基本统计",
    "找出销售最高的地区",
    "分析客户购买行为",
    "生成销售趋势报告"
]

results = []
for query in queries:
    result = client.query(query)
    results.append(result)

# 合并分析结果
combined_report = merge_analysis_results(results)
```

### 3. 定时分析任务

```python
# 设置定时分析任务
import schedule
import time

def daily_sales_analysis():
    """每日销售分析"""
    result = client.query("分析昨天的销售数据并生成日报")
    send_notification(result)

# 设置定时任务
schedule.every().day.at("09:00").do(daily_sales_analysis)

while True:
    schedule.run_pending()
    time.sleep(60)
```

## 性能优化建议

### 1. 缓存策略

```python
# 启用结果缓存
client = IntelligentDataAnalysisClient()
client.enable_cache(ttl=3600)  # 1小时缓存

# 缓存命中示例
result1 = client.query("分析销售数据")  # 第一次查询，缓存
result2 = client.query("分析销售数据")  # 第二次查询，命中缓存
```

### 2. 异步处理

```python
import asyncio

async def async_analysis(queries):
    """异步批量分析"""
    tasks = [client.query_async(query) for query in queries]
    results = await asyncio.gather(*tasks)
    return results

# 使用异步分析
queries = ["分析销售", "分析客户", "分析产品"]
results = await async_analysis(queries)
```

### 3. 数据预处理

```python
# 预加载常用数据集
client.preload_datasets([
    "sales_2024",
    "customer_data",
    "product_catalog"
])

# 预定义常用分析模板
templates = {
    "sales_summary": [
        {"type": "load_data", "source": "sales"},
        {"type": "date_filter", "period": "last_month"},
        {"type": "group_analysis", "by": "region"},
        {"type": "visualization", "type": "bar"}
    ]
}
```

这些示例展示了系统的各种使用方式，从简单的自然语言查询到复杂的数据分析工作流。您可以根据具体需求选择合适的交互方式。