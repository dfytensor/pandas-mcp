# 智能数据问答分析系统 - 配置文件

## 系统配置文件 (config.yaml)

```yaml
# 系统基础配置
system:
  name: "智能数据问答分析系统"
  version: "1.0.0"
  debug: false
  log_level: "INFO"
  
# 数据库配置
database:
  sqlite:
    default_path: "data/analysis.db"
    backup_path: "data/backups/"
    auto_backup: true
    backup_interval: 3600  # 秒
  
# 数据源配置
data_sources:
  sqlite:
    databases:
      - name: "sales_db"
        path: "data/sales.db"
        tables:
          - "orders"
          - "customers"
          - "products"
      - name: "analytics_db"
        path: "data/analytics.db"
        tables:
          - "user_events"
          - "performance_metrics"
  
  supported_formats:
    - "csv"
    - "json"
    - "excel"
    - "sqlite"
    - "parquet"

# 智能体配置
agents:
  intent_understanding:
    model_name: "chinese-bert-wwm-ext"
    confidence_threshold: 0.7
    max_context_length: 512
    
  task_decomposition:
    max_pipeline_steps: 20
    enable_optimization: true
    cache_results: true
    
  data_processing:
    batch_size: 10000
    enable_caching: true
    cache_ttl: 3600
    parallel_processing: true
    
  visualization:
    default_theme: "dark"
    chart_types:
      - "bar"
      - "line"
      - "scatter"
      - "histogram"
      - "heatmap"
      - "box"
    export_formats:
      - "png"
      - "svg"
      - "html"

# 缓存配置
cache:
  redis:
    host: "localhost"
    port: 6379
    db: 0
    password: null
  
  local:
    cache_dir: "cache/"
    max_size: "1GB"
    ttl: 3600

# API配置
api:
  host: "0.0.0.0"
  port: 8000
  workers: 4
  timeout: 300
  cors_origins:
    - "http://localhost:3000"
    - "http://localhost:8080"

# 安全配置
security:
  api_key_required: false
  rate_limiting:
    enabled: true
    requests_per_minute: 100
  encryption:
    enabled: true
    algorithm: "AES-256"

# 性能配置
performance:
  max_concurrent_queries: 10
  query_timeout: 120
  memory_limit: "2GB"
  cpu_limit: "80%"
  
# 日志配置
logging:
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  file: "logs/system.log"
  max_file_size: "10MB"
  backup_count: 5

# 可视化配置
visualization:
  theme: "dark"
  color_schemes:
    default: "viridis"
    categorical: "category10"
    sequential: "plasma"
  
  default_dimensions:
    width: 800
    height: 600
    dpi: 100
  
  export_settings:
    background_transparent: false
    font_family: "Inter"
    font_size: 12
```

## Docker部署配置

### Dockerfile

```dockerfile
FROM python:3.9-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    && rm -rf /var/lib/apt/lists/*

# 复制依赖文件
COPY requirements.txt .

# 安装Python依赖
RUN pip install --no-cache-dir -r requirements.txt

# 复制应用代码
COPY . .

# 创建数据目录
RUN mkdir -p data logs cache

# 设置环境变量
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1

# 暴露端口
EXPOSE 8000

# 启动命令
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  # 主应用服务
  api-server:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=sqlite:///data/analysis.db
      - REDIS_URL=redis://redis:6379
      - LOG_LEVEL=INFO
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
      - ./cache:/app/cache
    depends_on:
      - redis
      - postgres
    restart: unless-stopped
    networks:
      - analysis-network

  # Redis缓存服务
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped
    networks:
      - analysis-network

  # PostgreSQL数据库（可选，用于复杂分析）
  postgres:
    image: postgres:13
    environment:
      POSTGRES_DB: analysis_db
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: password123
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql
    restart: unless-stopped
    networks:
      - analysis-network

  # 异步任务处理服务
  worker:
    build: .
    command: celery -A main.celery worker --loglevel=info
    environment:
      - DATABASE_URL=sqlite:///data/analysis.db
      - REDIS_URL=redis://redis:6379
      - CELERY_BROKER_URL=redis://redis:6379
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    depends_on:
      - redis
    restart: unless-stopped
    networks:
      - analysis-network

  # 监控服务
  monitoring:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    restart: unless-stopped
    networks:
      - analysis-network

  # 可视化服务（前端）
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - REACT_APP_API_URL=http://localhost:8000
    depends_on:
      - api-server
    restart: unless-stopped
    networks:
      - analysis-network

volumes:
  redis_data:
  postgres_data:
  prometheus_data:

networks:
  analysis-network:
    driver: bridge
```

## 前端配置 (React)

### package.json

```json
{
  "name": "intelligent-data-analysis-frontend",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "typescript": "^4.9.0",
    "tailwindcss": "^3.2.0",
    "lucide-react": "^0.263.0",
    "recharts": "^2.7.0",
    "react-query": "^3.39.0",
    "socket.io-client": "^4.7.0"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  }
}
```

### tailwind.config.js

```javascript
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          400: '#6366F1',
          500: '#4F46E5',
          600: '#4338CA',
        },
        gray: {
          950: '#0A0A0A',
          900: 'rgba(20,20,20,0.5)',
          800: '#262626',
          300: '#D4D4D8',
          100: '#F4F4F5',
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      backdropBlur: {
        xs: '2px',
      },
      boxShadow: {
        'glow': '0 0 16px rgba(79, 70, 229, 0.3)',
        'card': '0 8px 32px rgba(0, 0, 0, 0.2)',
      }
    },
  },
  plugins: [],
}
```

## 环境变量配置

### .env

```bash
# 应用配置
APP_NAME=智能数据问答分析系统
APP_VERSION=1.0.0
DEBUG=false
LOG_LEVEL=INFO

# 数据库配置
DATABASE_URL=sqlite:///data/analysis.db
POSTGRES_URL=postgresql://admin:password123@localhost:5432/analysis_db

# Redis配置
REDIS_URL=redis://localhost:6379/0
REDIS_PASSWORD=

# API配置
API_HOST=0.0.0.0
API_PORT=8000
API_KEY=

# 安全配置
SECRET_KEY=your-secret-key-here
ENCRYPTION_KEY=your-encryption-key-here

# 性能配置
MAX_CONCURRENT_QUERIES=10
QUERY_TIMEOUT=120
MEMORY_LIMIT=2GB

# 缓存配置
CACHE_TTL=3600
CACHE_MAX_SIZE=1GB

# 日志配置
LOG_FILE=logs/system.log
LOG_MAX_SIZE=10MB
LOG_BACKUP_COUNT=5

# 监控配置
ENABLE_METRICS=true
METRICS_PORT=9090
```

## 部署脚本

### deploy.sh

```bash
#!/bin/bash

# 智能数据问答分析系统部署脚本

set -e

echo "🚀 开始部署智能数据问答分析系统..."

# 检查Docker是否安装
if ! command -v docker &> /dev/null; then
    echo "❌ Docker未安装，请先安装Docker"
    exit 1
fi

# 检查docker-compose是否安装
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose未安装，请先安装Docker Compose"
    exit 1
fi

# 创建必要的目录
echo "📁 创建目录结构..."
mkdir -p data logs cache backups frontend/build

# 设置权限
chmod 755 data logs cache backups

# 构建前端（如果存在）
if [ -d "frontend" ]; then
    echo "🏗️ 构建前端应用..."
    cd frontend
    npm install
    npm run build
    cd ..
fi

# 停止现有服务
echo "🛑 停止现有服务..."
docker-compose down

# 清理旧镜像
echo "🧹 清理旧镜像..."
docker system prune -f

# 构建并启动服务
echo "🔨 构建并启动服务..."
docker-compose up -d --build

# 等待服务启动
echo "⏳ 等待服务启动..."
sleep 30

# 检查服务状态
echo "🔍 检查服务状态..."
docker-compose ps

# 运行数据库迁移（如果需要）
echo "📊 初始化数据库..."
# python scripts/init_database.py

# 创建管理员用户（如果需要）
echo "👤 创建管理员用户..."
# python scripts/create_admin.py

echo "✅ 部署完成！"
echo "🌐 访问地址:"
echo "   - API服务: http://localhost:8000"
echo "   - 前端界面: http://localhost:3000"
echo "   - 监控面板: http://localhost:9090"
echo ""
echo "📚 API文档: http://localhost:8000/docs"
echo "🔧 健康检查: http://localhost:8000/health"
```

## 监控配置

### prometheus.yml

```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'api-server'
    static_configs:
      - targets: ['api-server:8000']
    metrics_path: '/metrics'
    scrape_interval: 5s

  - job_name: 'redis'
    static_configs:
      - targets: ['redis:6379']

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres:5432']
```

## 备份脚本

### backup.sh

```bash
#!/bin/bash

# 数据备份脚本

BACKUP_DIR="backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/backup_$DATE.tar.gz"

echo "开始备份数据..."

# 创建备份目录
mkdir -p $BACKUP_DIR

# 备份数据库
echo "备份SQLite数据库..."
cp data/analysis.db "$BACKUP_DIR/analysis_$DATE.db"

# 备份配置文件
echo "备份配置文件..."
tar -czf "$BACKUP_FILE" \
    data/ \
    logs/ \
    config.yaml \
    .env

# 清理旧备份（保留最近30天）
find $BACKUP_DIR -name "backup_*.tar.gz" -mtime +30 -delete
find $BACKUP_DIR -name "analysis_*.db" -mtime +30 -delete

echo "备份完成: $BACKUP_FILE"

# 可选：上传到云存储
# aws s3 cp "$BACKUP_FILE" s3://your-backup-bucket/
```

## 启动脚本

### start.sh

```bash
#!/bin/bash

# 系统启动脚本

echo "启动智能数据问答分析系统..."

# 检查端口占用
if lsof -Pi :8000 -sTCP:LISTEN -t >/dev/null ; then
    echo "⚠️ 端口8000已被占用"
    exit 1
fi

# 启动服务
docker-compose up -d

# 等待服务启动
echo "⏳ 等待服务启动..."
sleep 15

# 检查健康状态
if curl -f http://localhost:8000/health >/dev/null 2>&1; then
    echo "✅ 服务启动成功"
    echo "🌐 访问地址: http://localhost:8000"
else
    echo "❌ 服务启动失败"
    docker-compose logs
    exit 1
fi
```

## 停止脚本

### stop.sh

```bash
#!/bin/bash

# 系统停止脚本

echo "停止智能数据问答分析系统..."

# 停止服务
docker-compose down

echo "✅ 服务已停止"
```

这套配置文件和部署方案提供了完整的系统部署和运维支持，包括开发、测试和生产环境的配置。