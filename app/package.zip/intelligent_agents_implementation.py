"""
智能数据问答分析系统 - 核心智能体实现示例
基于您提供的FastMCP代码进行扩展
"""

import pandas as pd
import numpy as np
import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncio
from abc import ABC, abstractmethod


class BaseAgent(ABC):
    """智能体基类"""
    
    def __init__(self, name: str):
        self.name = name
        self.capabilities = []
        self.context = {}
    
    @abstractmethod
    async def process(self, input_data: Any) -> Dict[str, Any]:
        """处理输入数据"""
        pass
    
    def log(self, message: str, level: str = "INFO"):
        """记录日志"""
        timestamp = datetime.now().isoformat()
        print(f"[{timestamp}] [{level}] [{self.name}] {message}")


class IntentUnderstandingAgent(BaseAgent):
    """意图理解智能体"""
    
    def __init__(self):
        super().__init__("意图理解智能体")
        self.intent_patterns = {
            'data_query': ['查询', '显示', '找出', '统计', '多少', '哪些'],
            'data_analysis': ['分析', '对比', '趋势', '相关性', '分布', '特征'],
            'visualization': ['图表', '可视化', '画图', '展示', '图形'],
            'data_cleaning': ['清洗', '清理', '去重', '填充', '缺失'],
            'aggregation': ['汇总', '分组', '聚合', '求和', '平均'],
            'comparison': ['比较', '对比', '差异', '哪个更好']
        }
        
        self.entity_patterns = {
            'data_source': ['数据库', '表', '文件', 'CSV', 'Excel', 'JSON'],
            'time_reference': ['今天', '昨天', '本周', '上月', '今年', '去年'],
            'comparison_words': ['比', '相对于', '与...相比', '增长', '下降']
        }
    
    async def process(self, user_input: str) -> Dict[str, Any]:
        """解析用户意图"""
        self.log(f"解析用户输入: {user_input}")
        
        # 1. 意图识别
        intent_scores = {}
        for intent, keywords in self.intent_patterns.items():
            score = sum(1 for keyword in keywords if keyword in user_input)
            if score > 0:
                intent_scores[intent] = score
        
        # 2. 实体提取
        entities = self._extract_entities(user_input)
        
        # 3. 参数解析
        parameters = self._extract_parameters(user_input)
        
        result = {
            'intent': max(intent_scores.items(), key=lambda x: x[1])[0] if intent_scores else 'data_query',
            'confidence': max(intent_scores.values()) if intent_scores else 0.5,
            'entities': entities,
            'parameters': parameters,
            'original_text': user_input
        }
        
        self.log(f"意图解析结果: {result}")
        return result
    
    def _extract_entities(self, text: str) -> Dict[str, List[str]]:
        """提取实体"""
        entities = {}
        for entity_type, patterns in self.entity_patterns.items():
            found_entities = []
            for pattern in patterns:
                if pattern in text:
                    found_entities.append(pattern)
            if found_entities:
                entities[entity_type] = found_entities
        return entities
    
    def _extract_parameters(self, text: str) -> Dict[str, Any]:
        """提取参数"""
        parameters = {}
        
        # 提取数值
        numbers = re.findall(r'\d+(?:\.\d+)?', text)
        if numbers:
            parameters['numbers'] = [float(n) for n in numbers]
        
        # 提取列名（简单模式）
        column_matches = re.findall(r'[的](\w+)[数据列字段]', text)
        if column_matches:
            parameters['columns'] = column_matches
        
        return parameters


class TaskDecompositionAgent(BaseAgent):
    """任务分解智能体"""
    
    def __init__(self):
        super().__init__("任务分解智能体")
        self.task_templates = {
            'data_query': [
                {'type': 'load_data', 'name': '加载数据'},
                {'type': 'filter_data', 'name': '数据过滤'},
                {'type': 'analyze_data', 'name': '基础分析'}
            ],
            'data_analysis': [
                {'type': 'load_data', 'name': '加载数据'},
                {'type': 'clean_data', 'name': '数据清洗'},
                {'type': 'statistical_analysis', 'name': '统计分析'},
                {'type': 'correlation_analysis', 'name': '相关性分析'}
            ],
            'visualization': [
                {'type': 'load_data', 'name': '加载数据'},
                {'type': 'data_preparation', 'name': '数据准备'},
                {'type': 'create_visualization', 'name': '创建可视化'},
                {'type': 'chart_optimization', 'name': '图表优化'}
            ],
            'comparison': [
                {'type': 'load_data', 'name': '加载数据'},
                {'type': 'group_analysis', 'name': '分组对比'},
                {'type': 'statistical_comparison', 'name': '统计对比'},
                {'type': 'visual_comparison', 'name': '可视化对比'}
            ]
        }
    
    async def process(self, intent_result: Dict[str, Any]) -> List[Dict[str, Any]]:
        """分解任务为可执行的步骤"""
        intent = intent_result['intent']
        entities = intent_result.get('entities', {})
        
        self.log(f"分解任务，意图: {intent}")
        
        # 获取基础模板
        base_pipeline = self.task_templates.get(intent, self.task_templates['data_query'])
        
        # 根据实体和参数自定义流水线
        customized_pipeline = self._customize_pipeline(base_pipeline, intent_result)
        
        # 添加执行计划信息
        for i, step in enumerate(customized_pipeline):
            step['step_id'] = i + 1
            step['estimated_time'] = self._estimate_step_time(step)
            step['dependencies'] = self._get_dependencies(step, customized_pipeline[:i])
        
        self.log(f"生成流水线: {len(customized_pipeline)} 步")
        return customized_pipeline
    
    def _customize_pipeline(self, base_pipeline: List[Dict], intent_result: Dict) -> List[Dict]:
        """根据意图结果自定义流水线"""
        pipeline = base_pipeline.copy()
        entities = intent_result.get('entities', {})
        
        # 如果涉及数据源，添加数据源检测
        if 'data_source' in entities:
            pipeline.insert(0, {
                'type': 'detect_data_source',
                'name': '检测数据源',
                'params': {'source_types': entities['data_source']}
            })
        
        # 如果需要对比分析，添加对比步骤
        if intent_result['intent'] == 'comparison':
            pipeline.append({
                'type': 'generate_comparison_report',
                'name': '生成对比报告'
            })
        
        return pipeline
    
    def _estimate_step_time(self, step: Dict) -> int:
        """估算步骤执行时间（秒）"""
        time_estimates = {
            'load_data': 5,
            'detect_data_source': 3,
            'clean_data': 10,
            'filter_data': 2,
            'analyze_data': 5,
            'statistical_analysis': 8,
            'create_visualization': 15,
            'group_analysis': 6,
            'generate_comparison_report': 10
        }
        return time_estimates.get(step['type'], 5)
    
    def _get_dependencies(self, current_step: Dict, previous_steps: List[Dict]) -> List[int]:
        """获取步骤依赖关系"""
        dependencies = []
        
        # 数据加载步骤是其他步骤的基础
        if current_step['type'] != 'load_data':
            for i, step in enumerate(previous_steps):
                if step['type'] == 'load_data':
                    dependencies.append(step['step_id'])
                    break
        
        return dependencies


class DataProcessingAgent(BaseAgent):
    """数据处理智能体"""
    
    def __init__(self, mcp_engine):
        super().__init__("数据处理智能体")
        self.mcp_engine = mcp_engine  # 基于您现有的FastMCP引擎
        self.processing_cache = {}
    
    async def process(self, pipeline_config: List[Dict]) -> Dict[str, Any]:
        """执行数据处理流水线"""
        self.log(f"开始执行流水线，共 {len(pipeline_config)} 步")
        
        execution_results = []
        current_data = None
        dataset_id = None
        
        for step in pipeline_config:
            self.log(f"执行步骤: {step['name']} ({step['type']})")
            
            try:
                # 根据步骤类型执行相应操作
                if step['type'] == 'load_data':
                    result = await self._load_data(step)
                    dataset_id = result.get('dataset_id')
                    current_data = result.get('data')
                
                elif step['type'] == 'clean_data':
                    result = await self._clean_data(current_data, step)
                    current_data = result.get('data')
                
                elif step['type'] == 'filter_data':
                    result = await self._filter_data(current_data, step)
                    current_data = result.get('data')
                
                elif step['type'] == 'analyze_data':
                    result = await self._analyze_data(current_data, step)
                
                elif step['type'] == 'statistical_analysis':
                    result = await self._statistical_analysis(current_data, step)
                
                elif step['type'] == 'create_visualization':
                    result = await self._create_visualization(current_data, step)
                
                else:
                    result = {'success': False, 'error': f'不支持的步骤类型: {step["type"]}'}
                
                execution_results.append({
                    'step_id': step['step_id'],
                    'step_name': step['name'],
                    'step_type': step['type'],
                    'result': result,
                    'timestamp': datetime.now().isoformat()
                })
                
                if not result.get('success', True):
                    self.log(f"步骤执行失败: {result.get('error')}", "ERROR")
                    break
                    
            except Exception as e:
                self.log(f"步骤执行异常: {str(e)}", "ERROR")
                execution_results.append({
                    'step_id': step['step_id'],
                    'step_name': step['name'],
                    'step_type': step['type'],
                    'result': {'success': False, 'error': str(e)},
                    'timestamp': datetime.now().isoformat()
                })
                break
        
        return {
            'success': True,
            'execution_results': execution_results,
            'final_dataset_id': dataset_id,
            'final_data_shape': current_data.shape if current_data is not None else None,
            'total_steps': len(pipeline_config),
            'completed_steps': len([r for r in execution_results if r['result'].get('success', True)])
        }
    
    async def _load_data(self, step: Dict) -> Dict[str, Any]:
        """加载数据"""
        # 这里可以集成您现有的load_data方法
        # 简化示例
        return {
            'success': True,
            'dataset_id': f"dataset_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'data': pd.DataFrame({'sample': [1, 2, 3]}),
            'message': '数据加载成功'
        }
    
    async def _clean_data(self, data: pd.DataFrame, step: Dict) -> Dict[str, Any]:
        """数据清洗"""
        if data is None:
            return {'success': False, 'error': '没有可清洗的数据'}
        
        # 使用您现有的clean_block方法
        original_shape = data.shape
        
        # 示例清洗操作
        cleaned_data = data.dropna()  # 删除空值
        
        return {
            'success': True,
            'data': cleaned_data,
            'message': f'数据清洗完成: {original_shape} -> {cleaned_data.shape}',
            'details': {
                'rows_removed': original_shape[0] - cleaned_data.shape[0],
                'columns_removed': original_shape[1] - cleaned_data.shape[1]
            }
        }
    
    async def _filter_data(self, data: pd.DataFrame, step: Dict) -> Dict[str, Any]:
        """数据过滤"""
        if data is None:
            return {'success': False, 'error': '没有可过滤的数据'}
        
        # 使用您现有的filter_block方法
        return {
            'success': True,
            'data': data,  # 简化示例
            'message': '数据过滤完成'
        }
    
    async def _analyze_data(self, data: pd.DataFrame, step: Dict) -> Dict[str, Any]:
        """基础数据分析"""
        if data is None:
            return {'success': False, 'error': '没有可分析的数据'}
        
        analysis_result = {
            'shape': data.shape,
            'columns': list(data.columns),
            'dtypes': {col: str(dtype) for col, dtype in data.dtypes.items()},
            'null_counts': data.isnull().sum().to_dict(),
            'description': data.describe().to_dict() if not data.select_dtypes(include=[np.number]).empty else {}
        }
        
        return {
            'success': True,
            'analysis': analysis_result,
            'message': '数据分析完成'
        }
    
    async def _statistical_analysis(self, data: pd.DataFrame, step: Dict) -> Dict[str, Any]:
        """统计分析"""
        if data is None:
            return {'success': False, 'error': '没有可分析的数据'}
        
        numeric_data = data.select_dtypes(include=[np.number])
        if numeric_data.empty:
            return {'success': False, 'error': '没有数值型数据可分析'}
        
        stats_result = {
            'correlation_matrix': numeric_data.corr().to_dict(),
            'descriptive_stats': numeric_data.describe().to_dict(),
            'data_quality': {
                'completeness': (1 - data.isnull().sum().sum() / (data.shape[0] * data.shape[1])) * 100,
                'uniqueness': len(data.drop_duplicates()) / len(data) * 100
            }
        }
        
        return {
            'success': True,
            'statistics': stats_result,
            'message': '统计分析完成'
        }
    
    async def _create_visualization(self, data: pd.DataFrame, step: Dict) -> Dict[str, Any]:
        """创建可视化"""
        if data is None:
            return {'success': False, 'error': '没有数据可可视化'}
        
        # 使用您现有的visualize_block方法
        # 这里返回可视化配置
        viz_config = {
            'chart_type': 'auto',  # 智能推荐图表类型
            'recommended_charts': self._recommend_chart_types(data),
            'data_summary': {
                'shape': data.shape,
                'numeric_columns': list(data.select_dtypes(include=[np.number]).columns),
                'categorical_columns': list(data.select_dtypes(include=['object']).columns)
            }
        }
        
        return {
            'success': True,
            'visualization_config': viz_config,
            'message': '可视化配置生成完成'
        }
    
    def _recommend_chart_types(self, data: pd.DataFrame) -> List[str]:
        """智能推荐图表类型"""
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        categorical_cols = data.select_dtypes(include=['object']).columns
        
        recommendations = []
        
        if len(numeric_cols) >= 2:
            recommendations.extend(['scatter', 'correlation_heatmap'])
        
        if len(categorical_cols) >= 1 and len(numeric_cols) >= 1:
            recommendations.extend(['bar', 'box'])
        
        if len(numeric_cols) >= 1:
            recommendations.extend(['histogram', 'box'])
        
        return recommendations[:3]  # 返回前3个推荐


class VisualizationAgent(BaseAgent):
    """可视化智能体"""
    
    def __init__(self):
        super().__init__("可视化智能体")
        self.chart_configs = {
            'bar': {'type': 'bar', 'suitable_for': 'categorical_data'},
            'line': {'type': 'line', 'suitable_for': 'time_series'},
            'scatter': {'type': 'scatter', 'suitable_for': 'correlation'},
            'histogram': {'type': 'histogram', 'suitable_for': 'distribution'},
            'heatmap': {'type': 'heatmap', 'suitable_for': 'correlation_matrix'}
        }
    
    async def process(self, data_info: Dict[str, Any], visualization_config: Dict[str, Any]) -> Dict[str, Any]:
        """生成可视化"""
        self.log("开始生成可视化")
        
        # 1. 分析数据特征
        data_analysis = self._analyze_data_for_visualization(data_info)
        
        # 2. 推荐最佳图表类型
        recommended_charts = self._recommend_optimal_charts(data_analysis)
        
        # 3. 生成图表配置
        chart_configs = []
        for chart_type in recommended_charts:
            config = self._generate_chart_config(chart_type, data_info, visualization_config)
            chart_configs.append(config)
        
        return {
            'success': True,
            'data_analysis': data_analysis,
            'recommended_charts': recommended_charts,
            'chart_configs': chart_configs,
            'render_instructions': self._generate_render_instructions(chart_configs)
        }
    
    def _analyze_data_for_visualization(self, data_info: Dict[str, Any]) -> Dict[str, Any]:
        """分析数据特征以优化可视化"""
        shape = data_info.get('shape', (0, 0))
        columns = data_info.get('columns', [])
        
        analysis = {
            'data_size': 'small' if shape[0] < 1000 else 'large' if shape[0] > 10000 else 'medium',
            'dimensionality': 'low' if shape[1] < 5 else 'high' if shape[1] > 20 else 'medium',
            'column_count': len(columns),
            'row_count': shape[0]
        }
        
        # 分析列类型
        numeric_cols = [col for col, dtype in data_info.get('dtypes', {}).items() 
                       if 'int' in dtype or 'float' in dtype]
        categorical_cols = [col for col, dtype in data_info.get('dtypes', {}).items() 
                          if 'object' in dtype or 'str' in dtype]
        
        analysis.update({
            'numeric_columns': numeric_cols,
            'categorical_columns': categorical_cols,
            'has_time_data': any('time' in col.lower() or 'date' in col.lower() for col in columns)
        })
        
        return analysis
    
    def _recommend_optimal_charts(self, data_analysis: Dict[str, Any]) -> List[str]:
        """推荐最优图表类型"""
        recommendations = []
        
        # 基于数据特征推荐图表
        if data_analysis['has_time_data'] and len(data_analysis['numeric_columns']) > 0:
            recommendations.append('line')
        
        if len(data_analysis['categorical_columns']) > 0 and len(data_analysis['numeric_columns']) > 0:
            recommendations.append('bar')
        
        if len(data_analysis['numeric_columns']) >= 2:
            recommendations.append('scatter')
        
        if len(data_analysis['numeric_columns']) >= 1:
            recommendations.append('histogram')
        
        if len(data_analysis['numeric_columns']) >= 2:
            recommendations.append('heatmap')
        
        return recommendations[:3]  # 限制推荐数量
    
    def _generate_chart_config(self, chart_type: str, data_info: Dict, viz_config: Dict) -> Dict[str, Any]:
        """生成图表配置"""
        base_config = {
            'type': chart_type,
            'title': f'{chart_type.title()} Chart',
            'width': 800,
            'height': 600,
            'theme': 'dark'  # 匹配设计规范
        }
        
        # 根据图表类型添加特定配置
        if chart_type == 'bar':
            base_config.update({
                'x_axis': data_info.get('categorical_columns', [''])[0] if data_info.get('categorical_columns') else None,
                'y_axis': data_info.get('numeric_columns', [''])[0] if data_info.get('numeric_columns') else None,
                'color_scheme': 'viridis'
            })
        
        elif chart_type == 'scatter':
            if len(data_info.get('numeric_columns', [])) >= 2:
                base_config.update({
                    'x_axis': data_info['numeric_columns'][0],
                    'y_axis': data_info['numeric_columns'][1],
                    'size_by': data_info['numeric_columns'][2] if len(data_info['numeric_columns']) > 2 else None
                })
        
        return base_config
    
    def _generate_render_instructions(self, chart_configs: List[Dict]) -> Dict[str, Any]:
        """生成渲染指令"""
        return {
            'render_order': [config['type'] for config in chart_configs],
            'global_settings': {
                'font_family': 'Inter, sans-serif',
                'background_color': '#0A0A0A',
                'text_color': '#F4F4F5',
                'grid_color': '#262626'
            },
            'animation': {
                'duration': 300,
                'easing': 'ease-in-out'
            }
        }


class AgentCoordinator:
    """智能体协调器"""
    
    def __init__(self, mcp_engine):
        self.mcp_engine = mcp_engine
        self.agents = {
            'intent_understanding': IntentUnderstandingAgent(),
            'task_decomposition': TaskDecompositionAgent(),
            'data_processing': DataProcessingAgent(mcp_engine),
            'visualization': VisualizationAgent()
        }
        self.workflow_history = []
    
    async def process_user_query(self, user_query: str) -> Dict[str, Any]:
        """协调处理用户查询"""
        self.log(f"开始处理用户查询: {user_query}")
        
        try:
            # 1. 意图理解
            intent_result = await self.agents['intent_understanding'].process(user_query)
            
            # 2. 任务分解
            task_pipeline = await self.agents['task_decomposition'].process(intent_result)
            
            # 3. 执行数据处理
            processing_result = await self.agents['data_processing'].process(task_pipeline)
            
            # 4. 生成可视化（如果需要）
            visualization_result = None
            if intent_result.get('intent') in ['visualization', 'data_analysis', 'comparison']:
                if processing_result.get('success') and processing_result.get('final_data_shape'):
                    data_info = {
                        'shape': processing_result['final_data_shape'],
                        'columns': [],  # 这里应该从实际数据中获取
                        'dtypes': {}    # 这里应该从实际数据中获取
                    }
                    viz_config = {'chart_type': 'auto'}
                    visualization_result = await self.agents['visualization'].process(data_info, viz_config)
            
            # 5. 整合结果
            final_result = {
                'success': True,
                'user_query': user_query,
                'intent_recognition': intent_result,
                'task_pipeline': task_pipeline,
                'processing_result': processing_result,
                'visualization_result': visualization_result,
                'execution_summary': {
                    'total_steps': len(task_pipeline),
                    'completed_steps': processing_result.get('completed_steps', 0),
                    'success_rate': processing_result.get('completed_steps', 0) / len(task_pipeline) if task_pipeline else 0
                },
                'timestamp': datetime.now().isoformat()
            }
            
            # 记录工作流历史
            self.workflow_history.append(final_result)
            
            self.log("用户查询处理完成")
            return final_result
            
        except Exception as e:
            error_result = {
                'success': False,
                'user_query': user_query,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
            self.log(f"处理用户查询时出错: {str(e)}", "ERROR")
            return error_result
    
    def log(self, message: str, level: str = "INFO"):
        """统一日志记录"""
        timestamp = datetime.now().isoformat()
        print(f"[{timestamp}] [COORDINATOR] [{level}] {message}")


# 使用示例
async def main():
    """主函数示例"""
    # 初始化MCP引擎（基于您现有的代码）
    # mcp_engine = FastMCPDataEngine()
    
    # 初始化协调器
    # coordinator = AgentCoordinator(mcp_engine)
    
    # 示例查询
    sample_queries = [
        "帮我分析一下销售数据，看看各地区的销售趋势",
        "显示最近一个月的用户增长情况",
        "对比一下不同产品的销售表现",
        "生成一个关于客户满意度的可视化报告"
    ]
    
    for query in sample_queries:
        print(f"\n{'='*50}")
        print(f"处理查询: {query}")
        print(f"{'='*50}")
        
        # result = await coordinator.process_user_query(query)
        # print(f"处理结果: {json.dumps(result, indent=2, ensure_ascii=False)}")
        
        print("（示例代码，需要实际的MCP引擎实例才能运行）")


if __name__ == "__main__":
    asyncio.run(main())